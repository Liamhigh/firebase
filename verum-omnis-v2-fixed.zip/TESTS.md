# Verum Omnis V2 Testing Guide

This document outlines the testing strategy for the Verum Omnis V2 application, covering unit tests for core functionalities and integration tests for API endpoints.

## 1. Unit Tests

Unit tests focus on individual functions and components in isolation to ensure their correctness.

### A. Client-Side Hashing Functions (`web/js/script.js`)

**Objective:** Verify that the hashing logic in `web/js/script.js` correctly computes SHA-512 hashes.

**How to Test (Manual / Browser Console):**

1.  Start the Firebase emulators: `firebase emulators:start --only hosting,functions`.
2.  Open your browser to `http://localhost:5000/chat.html`.
3.  Open the browser's developer console (F12).
4.  **Test `voHashText(text)`:**
    ```javascript
    // Assume script.js is loaded and voHashText is globally available
    window.voHashText("file content").then(hash => console.log(hash));
    ```
    *   **Expected Output:** `0782e434e320d783307567ae2c510807b5a5e3f28325ef014ddcc69707e4d8ef8471b06c6460492c6c19f6a5b672721867e376a911a3b53c168f00d2383c2763`
5.  **Test `voHashFile(file)` (via UI):**
    *   In the "Forensic Firewall" panel, click "Upload evidence to locker".
    *   Select a small text file (e.g., `test.txt` with content "file content").
    *   **Expected:** The SHA-512 hash appears in the "Evidence Locker". Visually confirm it matches the expected hash above.

### B. PDF Sealing Function (`web/js/script.js`)

**Objective:** Verify that `voSealPdf` generates a valid PDF with correct content, watermark, footer, SHA-512, and QR code.

**How to Test (Manual / Browser UI):**

1.  Open `http://localhost:5000/chat.html`.
2.  **Generate a chat transcript:**
    *   Type a prompt in the input field (e.g., "Hello Verum Omnis V2, test PDF seal.").
    *   Click "Ask". Repeat with a few more messages.
3.  **Seal the transcript:**
    *   Click the "Seal Transcript to PDF" button.
    *   **Expected:** A PDF downloads.
4.  **Visual Inspection:**
    *   Open the downloaded `VERUM_OMNIS_V2_TRANSCRIPT_*.pdf`.
    *   Verify: Top-center logo, faint diagonal "VERUM OMNIS V2 - CONFIDENTIAL" watermark, correct chat transcript content.
    *   Check the footer: "✔ Patent Pending Verum Omnis V2", current date/time, `SHA-512: ...`, and a QR code.
    *   Scan the QR code to ensure it points to `http://localhost:5000/chat?mode=verify&hash=<sha512_of_transcript>`.

## 2. Integration Tests

Integration tests verify the interaction between different parts of the system, particularly client-side and server-side components.

### A. Firebase Functions API Endpoints

**Objective:** Ensure that the `/api/assistant`, `/api/verify`, and `/api/health` endpoints are accessible and return expected responses.

**How to Test (Local / Deployed `curl`):**

1.  **Start Firebase Emulators:** `firebase emulators:start --only functions` (for local testing) or ensure your app is deployed.
2.  **Test `/api/assistant`:**
    ```bash
    curl -X POST -H "Content-Type: application/json" \
         -d '{
               "prompt": "Explain contract law basics.",
               "context": "legal",
               "mode": "chat"
             }' \
         http://localhost:5001/api/assistant # Adjust port if different, or use deployed URL
    ```
    *   **Expected:** HTTP 200 OK. Response should contain `text` and `rawParts` from the three AI stubs.
3.  **Test `/api/verify`:**
    ```bash
    curl -X POST -H "Content-Type: application/json" \
         -d '{
               "sha512_prefix": "F9812DF678DBD3B6BAD400FD518DD8F472AC0F9A070458C007993078C51BDF468B356FD8055703AE9107346133DB5174AD33D03A9A9914848824D78E439F5832"
             }' \
         http://localhost:5001/api/verify
    ```
    *   **Expected:** HTTP 200 OK. Response should contain `ok: true` and the echoed `sha512_prefix`.
    ```bash
    # Test with invalid hash format
    curl -X POST -H "Content-Type: application/json" \
         -d '{
               "sha512_prefix": "invalidhash"
             }' \
         http://localhost:5001/api/verify
    ```
    *   **Expected:** HTTP 400 Bad Request. Response should indicate an invalid format.
4.  **Test `/api/health`:**
    ```bash
    curl http://localhost:5001/api/health
    ```
    *   **Expected:** HTTP 200 OK. Response should contain `status: "ok"` and a timestamp.

### B. Client-Server Integration (Full Chat Flow)

**Objective:** Verify the complete chat experience, including sending messages, receiving responses, file attachments, and PDF sealing. Also, test the new voice input.

**How to Test (Manual / Browser UI):**

1.  Open `http://localhost:5000/chat.html` in your browser.
2.  **Send a simple text message:**
    *   Type a prompt in the input field (e.g., "What is the process for filing a patent?").
    *   Click "Ask".
    *   **Expected:** User message appears, then loading indicator, then the AI's consensus response. Expand "View Triple-AI Raw Responses" to see individual AI outputs.
3.  **Use Voice Input:**
    *   Click the microphone icon next to the text area.
    *   Speak clearly into your microphone (e.g., "Summarize the legal obligations for a data breach.").
    *   **Expected:** The text area should show "Listening..." and then populate with your transcribed speech.
    *   Click "Ask".
    *   **Expected:** The AI responds to your voice-inputted prompt.
4.  **Attach a text file:**
    *   Click the paperclip icon.
    *   Select a small `.txt` file. The file name should appear above the input.
    *   Type a prompt (e.g., "Analyze this document for potential liabilities.").
    *   Click "Ask".
    *   **Expected:** User message with attachment, then AI response that incorporates the file content.
5.  **Attach a PDF file:**
    *   Click the paperclip icon.
    *   Select a small `.pdf` file. The file name should appear above the input.
    *   Type a prompt (e.g., "Summarize this PDF for me.").
    *   Click "Ask".
    *   **Expected:** User message with attachment, then AI response that incorporates the file content.
6.  **Verify a document hash (via URL):**
    *   Navigate directly to `http://localhost:5000/chat.html?mode=verify&hash=F9812DF678DBD3B6BAD400FD518DD8F472AC0F9A070458C007993078C51BDF468B356FD8055703AE9107346133DB5174AD33D03A9A9914848824D78E439F5832`.
    *   **Expected:** The "Forensic Firewall" input should be pre-populated, and the hash automatically verified with "INTEGRITY CONFIRMED".
7.  **Upload evidence to locker:**
    *   In the "Forensic Firewall" panel, click "Upload evidence to locker".
    *   Select a file.
    *   **Expected:** File name and SHA-512 appear in the "Evidence Locker".
8.  **Seal Evidence Bundle:**
    *   After adding files to the locker, click "Seal Evidence Bundle".
    *   **Expected:** A PDF downloads. Open it and visually inspect for content, logo, watermark, SHA-512 (of the manifest), and QR code.
9.  **Seal Transcript to PDF:**
    *   Have some chat messages in the log.
    *   Click "Seal Transcript to PDF".
    *   **Expected:** A PDF downloads. Open it and visually inspect for chat content, logo, watermark, SHA-512 (of the transcript), and QR code.
10. **Navigation Checks:**
    *   From `/chat.html`, use browser back button to `/index.html`.
    *   Click "For Institutions" from `index.html` to go to `/institutions.html`.
    *   Click "Back to Home" from `/institutions.html` to go back to `/index.html`.

## 3. GitHub Actions CI/CD Test

**Objective:** Verify that the GitHub workflow automatically builds and deploys the application on `push` to `main`.

**How to Test:**

1.  Commit and push a small change to the `main` branch of your GitHub repository.
2.  Go to your GitHub repository `Actions` tab.
3.  **Expected:** A new workflow run should be triggered, build the static `web/` app (or copy from `react-app/dist`), build functions successfully, and deploy to Firebase Hosting and Functions. Check the logs for any errors.
4.  After deployment, access your live Firebase Hosting URL to ensure the changes are reflected.

This comprehensive testing approach ensures the reliability, security, and functionality of Verum Omnis V2 across its various components.