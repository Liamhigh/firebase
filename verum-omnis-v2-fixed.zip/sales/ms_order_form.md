# Verum Omnis V2 — Master Service Order Form

**Effective Date:** [Date]
**Order Form Number:** [Unique Order Form ID]

---

## 1. Client Information

**Legal Entity Name:** __________________________________________________
**DBA Name (if different):** ____________________________________________
**Registered Address:** __________________________________________________
____________________________________________________________________
**Billing Contact Name:** ________________________________________________
**Billing Contact Email:** _______________________________________________
**Billing Contact Phone:** _______________________________________________
**Site Manager Name:** __________________________________________________
**Site Manager Email:** _________________________________________________
**Site Manager Phone:** _________________________________________________
**Primary Site ID (as used in VO System):** ______________________________

## 2. Selected Modules and Quantities

Please check the desired modules and specify quantities for each operational site.

| Module                       | Description                                                                     | Quantity (per site) | Unit Price (USD/month) | Total (USD/month) |
| :--------------------------- | :------------------------------------------------------------------------------ | :------------------ | :--------------------- | :---------------- |
| [ ] **Lane Monitoring**      | CCTV + POS Fusion for cashier lanes                                             | _________           | $________              | $________         |
| [ ] **Forecourt Monitoring** | CCTV for pump areas (per camera)                                                | _________           | $________              | $________         |
| [ ] **Access Sentinel**      | Sensor-based monitoring for doors (per sensor)                                  | _________           | $________              | $________         |
| [ ] **Site Platform Fee**    | Base fee per site (includes live scoreboard & incident sealing)                 | 1                   | $99.00                 | $99.00            |
| **Subtotal per Site**        |                                                                                 |                     | **TOTAL: $________**   |                   |

**Number of Operational Sites:** _________

## 3. Pricing Summary

**Total Monthly Recurring Cost (MRC):** USD $____________________
**Total Annual Recurring Cost (ARR):** USD $____________________

**Optional Outcome Bonus (if selected):**
[ ] Yes, apply an outcome bonus of _______ bps (basis points) on **audited prevented loss**.
    *   *Details: An additional fee calculated as a percentage of verified financial losses prevented by Verum Omnis V2, subject to quarterly audit.*

**Initial Term:** [ ] 12 Months / [ ] 24 Months / [ ] Other: __________
**Start Date of Services:** ________________________

## 4. Legal & Compliance Clauses (Mandatory)

By signing this Order Form, Client agrees to the following critical terms:

### 4.1. Data Processing Addendum (DPA)
Client acknowledges and agrees to the Verum Omnis V2 Data Processing Addendum, available at [Link to DPA URL], which forms an integral part of this agreement. This DPA outlines data privacy, security measures, and compliance with applicable data protection regulations (e.g., GDPR, CCPA).

### 4.2. Purpose Limitation
Client explicitly agrees that Verum Omnis V2 services shall be used **solely and exclusively** for the purposes of **fraud prevention, safety alerts, and court-evidence sealing**. Client shall **NOT** use Verum Omnis V2 for political repression, union activity monitoring, profiling protected classes, or any form of illegal, unethical, or discriminatory surveillance.

### 4.3. Breach of Purpose Limitation
Any confirmed breach of the Purpose Limitation clause (Section 4.2) by the Client shall constitute a material breach of this agreement, resulting in:
    *   Immediate **termination** of all Verum Omnis V2 licenses and services.
    *   Public disclosure of the breach in the Verum Omnis V2 transparency log, accessible at [Link to Transparency Log URL].
    *   Client shall be liable for any damages or legal costs incurred by Verum Omnis V2 due to such breach.

### 4.4. Dual-Key Activation for Sensitive Features
Client acknowledges that the activation or expansion of scope for sensitive security modules (e.g., new camera zones, additional sensor types, integration of new data streams) requires **dual-key activation**, involving both a designated Client Officer and a Verum Omnis V2 Ethics Officer. Each such activation will generate a public, hash-anchored **activation receipt** detailing who, what, when, and why, for immutable auditability.

### 4.5. Audit Rights
Verum Omnis V2, or a mutually agreed-upon neutral third-party auditor, shall have the right, upon reasonable notice, to conduct periodic audits of the Client's Verum Omnis V2 implementation to verify compliance with the terms of this Order Form, particularly Sections 4.2 and 4.4, using privacy-preserving hash proofs and black-box verification methods.

## 5. Acceptance

This Order Form, upon signature by both parties, constitutes a binding agreement for the provision of Verum Omnis V2 services as described herein.

**Client Acceptance:**

_______________________________________
[Client Company Name]

Name: _______________________________
Title: ________________________________
Date: _______________________________

**Verum Omnis V2 Acceptance:**

_______________________________________
Verum Omnis V2

Name: _______________________________
Title: ________________________________
Date: _______________________________