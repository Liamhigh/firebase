# Verum Omnis V2 — Retail Security Suite: Stop Fraud at the Source

**Verum Omnis V2** introduces a revolutionary AI-powered security suite, specifically engineered for retail environments like petrol forecourts and branch operations. We fuse real-time CCTV and POS/ledger data to catch fraud, enhance security, and deliver unprecedented operational intelligence – all while maintaining strict privacy.

---

## The Problem: Retail Fraud is Rife and Hard to Catch

Cashier skims, unauthorized no-sales, price swaps, refund fraud, and restricted item (e.g., cigarettes, lottery) leakage cost retailers billions annually. Traditional systems are reactive, miss subtle patterns, and often require extensive manual review, which is both costly and inefficient.

---

## Our Solution: Verum Omnis V2 — The Intelligent Firewall for Your Forecourt

We deploy a privacy-first edge AI system that seamlessly integrates with your existing infrastructure.

**Key Capabilities:**

*   **Live Fraud Detection**: Real-time alerts for:
    *   **Scan/Visual Mismatch**: POS says "Coke", camera sees "Energy Drink".
    *   **Price Swap / Open-Price Abuse**: Using generic PLUs for high-value barcoded items.
    *   **No-Sale Skims**: Cash drawer opens without a recorded transaction.
    *   **Refund/Void Fraud**: Unauthorized refunds without item returns.
    *   **Restricted Item Leakage**: Cigarettes/lotto slips leaving the cabinet without a POS scan.
    *   **Fuel Anomalies**: Pump authorizations not matching sales.
    *   **Bagging Bypass**: Items leaving the counter area without being scanned.
*   **CCTV + POS Fusion**: Intelligent algorithms correlate visual events with transaction data, identifying suspicious patterns invisible to humans.
*   **Privacy-First Design**: **No faces, no names, no PII stored.** Cashier and lane IDs are hashed. Video clips stay on-prem by default; only anonymized metadata and hash proofs are sent to the cloud.
*   **Court-Ready Evidence**: For critical incidents, generate tamper-evident PDF reports with hashed video clips and cryptographic proofs for audit and legal action.
*   **Live Scoreboard**: Managers get a real-time, aggregated view of security incidents and estimated prevented losses across their site(s).

---

## How It Works (At a Glance)

1.  **Edge AI Deployment**: A compact, powerful AI mini-PC integrates with your existing CCTV cameras (lane, cabinet, pump) and POS system (via adapters).
2.  **Real-Time Fusion**: Our `B10_Security_Retail` brain continuously analyzes synchronized video streams and POS events.
3.  **Intelligent Flagging**: Suspicious activities trigger alerts based on pre-defined governance rules.
4.  **Metadata Stream**: Only anonymized incident metadata (timestamps, rule IDs, hash prefixes, estimated amounts) is sent to the Verum Omnis V2 cloud relay.
5.  **Live Scoreboard**: Site managers view a real-time dashboard of incidents, trends, and key KPIs.

---

## Benefits: Immediate ROI and Unmatched Security

*   **Reduced Shrinkage**: Directly prevent and deter significant financial losses from fraud.
*   **Enhanced Auditability**: Comprehensive, cryptographically verifiable records for every incident.
*   **Operational Efficiency**: Automate fraud detection, freeing up staff for core tasks.
*   **Peace of Mind**: Know your operations are protected by cutting-edge, privacy-respecting AI.

---

## Pricing (Simple & Scalable)

*   **Per Lane / Month**: Starting from **$79**.
*   **Forecourt / Pump Camera / Month**: **$49** add-on.
*   **Site Platform Fee / Month**: **$99**.
*   **Outcome Bonus (Optional)**: `0.5–2.0 bps` of audited prevented loss.
*   Multi-site discounts available.

---

**Verum Omnis V2: Firewalled Justice for Your Business. Stop Fraud. Increase Profit. Stay Private.**

**Contact us today for a demo and a pilot program.**
[Your Contact Information]