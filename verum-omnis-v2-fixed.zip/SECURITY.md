# Verum Omnis V2 Security Posture

Verum Omnis V2 is designed with a strong emphasis on privacy and security, adhering to a "client-side forensics first" and "stateless for private users" philosophy. This document outlines the key security measures implemented.

## 1. API Key Handling (Zero-Trust Principle)

*   **Server-Side Proxying:** All interactions with external Large Language Models (LLMs) (e.g., Google Gemini) are exclusively proxied through Firebase Functions.
*   **No Client-Side Exposure:** API keys for LLMs are never embedded in client-side JavaScript or exposed to the user's browser. They are securely stored as environment variables within the Firebase Functions environment.
*   **Initialization:** The `@google/genai` client instance is initialized *only* within Firebase Functions, accessing the API key via `process.env.API_KEY`.

## 2. Data Privacy and Statelessness

*   **No PII Server Storage:** For private users, Verum Omnis V2 does not store any Personally Identifiable Information (PII), chat transcripts, or document contents on its servers.
*   **Client-Side Persistence:** Chat history, attached evidence file metadata, and sealed package manifests are stored ephemerally in the user's browser using **IndexedDB**. This provides a seamless user experience within a session and across browser refreshes, but this data **never leaves the user's device** unless explicitly downloaded by the user as a sealed PDF.
*   **Client-Side Hashing:** When users attach documents for forensic analysis, the SHA-512 cryptographic hash is computed entirely within the user's browser using WebCrypto API. Document content is never uploaded to Verum Omnis V2 servers for hashing.
*   **Server Log Minimization:** When server-side verification or AI assistance is used, only short prefixes of document hashes (for verification requests) or sanitized prompt data (for AI queries) are logged for operational integrity, never full hashes or sensitive original content.

## 3. Content Security Policy (CSP)

A strict Content Security Policy (CSP) is implemented via `helmet` in Firebase Functions to mitigate various cross-site scripting (XSS) and data injection attacks.

*   **`default-src 'self'`**: Only allows resources to be loaded from the application's origin by default.
*   **`script-src`**: Explicitly allows `'self'`, `'unsafe-inline'` (for very minimal inline scripts and event handlers), and `cdn.jsdelivr.net` (for `pdf-lib` and `qrcode-generator` CDNs).
*   **`style-src`**: Explicitly allows `'self'`, and `'unsafe-inline'` (for dynamically applied styles or very minimal inline CSS).
*   **`img-src`**: Allows `'self'`, `data:` (for QR codes and potentially embedded logo images).
*   **`media-src`**: Allows `'self'`, `blob:` (for Web Speech API and other media streams like hero video).
*   **`font-src`**: Allows `'self'` and `https://fonts.gstatic.com` (if Google Fonts are used).
*   **`connect-src`**: Allows `'self'`, `https://*.googleapis.com`, `https://*.web.app`, `https://*.firebaseapp.com` for secure communication with Google APIs (LLMs) and Firebase Hosting domains.
*   **`child-src`**: Specifically adds `'self'`, `blob:` for the Web Speech Recognition API if it uses an iframe or web worker.
*   **`worker-src`**: Adds `'self'`, `blob:` for web workers if used by Speech Recognition or other modules.

## 4. Cross-Origin Resource Sharing (CORS)

*   Firebase Functions (`/api`) are configured with `cors({ origin: true })`, which reflects the request's origin in the `Access-Control-Allow-Origin` header, effectively allowing cross-origin requests from the deployed Firebase Hosting domain.

## 5. Rate Limiting

*   The `/api` endpoints are protected by `express-rate-limit` to prevent abuse and denial-of-service attacks.
    *   **Limit:** 100 requests per 15 minutes per IP address.

## 6. Cache Control

*   **`Cache-Control: no-cache, no-store, must-revalidate`**: HTML, JavaScript, and CSS files served by Firebase Hosting are configured with aggressive no-cache headers. This ensures that users always receive the latest version of the client-side forensic logic and UI, preventing stale code from running.
*   **`Pragma: no-cache` and `Expires: 0`**: Additional headers for broader browser compatibility with no-caching directives.
*   **`Cache-Control: public, max-age=3600`**: Static assets like images and videos (`assets/**`) are cached for a short duration (1 hour) to improve performance, as they are not expected to change frequently.

## 7. Court-Ready Output Integrity

*   **Client-Side PDF Sealing:** Generated PDFs include a visible SHA-512 hash of the document's content, a timestamp, and a QR code. This allows for independent verification of the document's integrity and origin without relying on server-side logs.
*   **Verification Page:** The QR code embeds a URL that points to the application's verification mechanism (`/chat.html?mode=verify&hash=<sha512>`), enabling a user to confirm the hash of a physical printout.

## 8. Development Practices

*   **Minimal Dependencies:** Efforts are made to keep client-side dependencies minimal to reduce the attack surface. Only `pdf-lib` and `qrcode-generator` are used via CDN.
*   **Vanilla JavaScript:** The frontend is built using vanilla JavaScript, reducing the overhead and complexity introduced by frameworks.
*   **No `eval()` or `new Function()`:** Client-side JavaScript avoids dynamic code execution from untrusted sources.
*   **Regular Updates:** Dependencies (server-side functions) are kept up-to-date to patch known vulnerabilities.

This robust security framework underpins Verum Omnis V2, ensuring that users can confidently engage with advanced legal AI while maintaining control over their data and privacy.