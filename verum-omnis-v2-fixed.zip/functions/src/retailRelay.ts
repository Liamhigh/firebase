
import { onRequest, Request as FunctionsRequest, Response as FunctionsResponse } from "firebase-functions/v2/https";
import { getApp, getApps, initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { BigQuery } from "@google-cloud/bigquery";
import nodemailer from "nodemailer";
import * as logger from "firebase-functions/logger";
import * as admin from 'firebase-admin'; // Import firebase-admin

if (!getApps().length) initializeApp();
const db = getFirestore();
const bq = new BigQuery({});
const DATASET = process.env.BQ_DATASET || "vo_fraud";
const TABLE   = process.env.BQ_RETAIL || "retail_incidents"; // New table for retail

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST!, port: Number(process.env.SMTP_PORT||587),
  secure: String(process.env.SMTP_PORT)==="465",
  auth: { user: process.env.SMTP_USER!, pass: process.env.SMTP_PASS! }
});

// Helper function to increment retail KPIs
async function incrementKpis(siteId: string, record: any) {
  const siteDocRef = db.collection("sites").doc(siteId);
  const retailStatsRef = siteDocRef.collection("live").doc("retail");
  const now = Date.now();
  const isoDate = new Date(now).toISOString().slice(0,10); // YYYY-MM-DD

  try {
    await db.runTransaction(async (tx) => {
      const currentStats = (await tx.get(retailStatsRef)).data() || {};
      const amount = Number(record.amount_estimated || 0);

      const statsUpdate = {
        updated_at: now,
        incidents_all: (currentStats.incidents_all || 0) + 1,
        amount_all: (currentStats.amount_all || 0) + amount,
        
        // Daily counters
        amount_today: isoDate === currentStats.last_day ? (currentStats.amount_today || 0) + amount : amount,
        crit_today: isoDate === currentStats.last_day ? (currentStats.crit_today || 0) + (record.severity === 'CRITICAL' ? 1 : 0) : (record.severity === 'CRITICAL' ? 1 : 0),
        last_day: isoDate,
      };
      tx.set(retailStatsRef, statsUpdate, { merge: true });
    });
    logger.info("Retail KPIs incremented for site:", { siteId, incident_id: record.incident_id });
  } catch (error) {
    logger.error("Error incrementing retail KPIs for site:", { siteId, incident_id: record.incident_id, error });
  }
}

// POST body: { site_id, incident_id, ts, lane_id, action, amount_estimated?, currency?, rule_id, hash_prefix, severity, cashier_id_hash?, category? }
export const voRetailRelay = onRequest({ cors: true, maxInstances: 4 }, async (req: FunctionsRequest, res: FunctionsResponse) => {
  try {
    // Access req.method and req.body directly from functions v2 Request object
    if (req.method!=="POST") return res.status(405).send("Method Not Allowed");
    const p = req.body||{};
    if (!p.site_id || !p.incident_id) return res.status(400).send("Missing site_id/incident_id");

    // Add authentication logic for standalone function
    const authHeader = req.headers.authorization;
    let decodedToken: admin.auth.DecodedIdToken | undefined;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const idToken = authHeader.split('Bearer ')[1];
      try {
        decodedToken = await admin.auth().verifyIdToken(idToken);
      } catch (error) {
        logger.warn("Authentication: Error verifying ID token for retail relay.", error);
        return res.status(403).send('Forbidden: Invalid token');
      }
    } else {
        logger.warn("Authentication: No Authorization header for retail relay.");
        return res.status(401).send('Unauthorized: No token provided');
    }

    if (!decodedToken || !decodedToken.site_id) {
      logger.warn("Unauthenticated or missing site_id claim for retail relay request.");
      return res.status(403).send("Forbidden: Authentication required with site_id claim.");
    }
    if (decodedToken.site_id !== p.site_id) {
        logger.warn("Mismatched site_id claim for retail relay request.", { auth_site_id: decodedToken.site_id, payload_site_id: p.site_id });
        return res.status(403).send("Forbidden: site_id mismatch.");
    }

    const now = Date.now();
    const docRef = db.collection("sites").doc(String(p.site_id))
                     .collection("retailIncidents").doc(String(p.incident_id));
    const exists = await docRef.get();
    if (exists.exists) {
      logger.info("Duplicate retail incident received (idempotent)", { incident_id: p.incident_id, site_id: p.site_id });
      return res.status(200).send({ok:true, dedup:true});
    }

    const rec = {
      incident_id: String(p.incident_id),
      auth_uid: decodedToken.uid, // Add authenticated user's UID from decoded token
      ts: p.ts || new Date().toISOString(),
      site_id: String(p.site_id), // Store site_id from payload (validated by claim)
      lane_id: p.lane_id || null,
      rule_id: p.rule_id || null,
      action: p.action || "FLAG",
      severity: p.severity || "HIGH",
      amount_estimated: Number(p.amount_estimated||0),
      currency: p.currency || "USD",
      hash_prefix: p.hash_prefix || "",
      cashier_id_hash: p.cashier_id_hash || null,
      category: p.category || null,
      received_at: now
    };
    await docRef.set(rec);
    await incrementKpis(String(p.site_id), rec);

    // Append to BigQuery
    const rows = [{
      received_date: new Date(now).toISOString().slice(0,10),
      timestamp: rec.ts,
      auth_uid: rec.auth_uid,
      site_id: rec.site_id,
      lane_id: rec.lane_id,
      rule_id: rec.rule_id,
      action: rec.action,
      severity: rec.severity,
      amount_estimated: rec.amount_estimated,
      currency: rec.currency,
      incident_id: rec.incident_id,
      hash_prefix: rec.hash_prefix,
      cashier_id_hash: rec.cashier_id_hash,
      category: rec.category,
    }];
    await bq.dataset(DATASET).table(TABLE).insert(rows).catch(err => {
      logger.error("BigQuery retail incident insert failed:", err);
      if (err.name === 'PartialFailureError' && err.errors && err.errors.length > 0) {
        err.errors.forEach((e: any) => logger.error("BigQuery retail row error:", e));
      }
    });

    if (process.env.RETAIL_EMAIL_TO) {
      const text = `Site: ${p.site_id}\nLane: ${rec.lane_id}\nRule: ${rec.rule_id}\nSeverity: ${rec.severity}\nAction: ${rec.action}\nEstimate: ${rec.currency} ${rec.amount_estimated}\nIncident: ${p.incident_id}\nHash: ${rec.hash_prefix}\nTime: ${rec.ts}\nCashier: ${rec.cashier_id_hash || 'N/A'}\nCategory: ${rec.category || 'N/A'}`;
      await transporter.sendMail({ from:`"Verum Omnis V2 Retail" <no-reply@verumglobal.foundation>`, to: process.env.RETAIL_EMAIL_TO, subject:`Retail Incident ${rec.severity} — ${p.site_id}`, text });
    }
    return res.status(200).send({ ok: true });
  } catch (e:any) {
    logger.error("voRetailRelay error:", e);
    return res.status(500).send("Server error during retail incident processing.");
  }
});