
import { onRequest, Request as FunctionsRequest, Response as FunctionsResponse } from "firebase-functions/v2/https";
import * as logger from "firebase-functions/logger";
import nodemailer from "nodemailer";
import crypto from "crypto";
import { getApp, getApps, initializeApp } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { BigQuery } from "@google-cloud/bigquery";
import * as admin from 'firebase-admin'; // Import firebase-admin

// Initialize Firebase Admin SDK only once
if (!getApps().length) {
  initializeApp();
}

const db = getFirestore();
const bq = new BigQuery(); // uses service account configured for the Firebase project
// Access configuration via process.env for v2 functions
const DATASET = process.env.BQ_DATASET || "vo_fraud";
const TABLE   = process.env.BQ_TABLE   || "events";

// SMTP secrets loaded via functions:secrets:set as before
const SMTP_HOST = process.env.SMTP_HOST!;
const SMTP_PORT = Number(process.env.SMTP_PORT || 587);
const SMTP_USER = process.env.SMTP_USER!;
const SMTP_PASS = process.env.SMTP_PASS!;
const HMAC_SECRET = process.env.HMAC_SECRET || "";  // optional client HMAC verification

const transporter = nodemailer.createTransport({
  host: SMTP_HOST, port: SMTP_PORT, secure: SMTP_PORT === 465,
  auth: { user: SMTP_USER, pass: SMTP_PASS }
});

// Helper function to send email
async function maybeSendEmail(to?: string, subject?: string, body?: any){
  const t = to || "documents@verumglobal.foundation";
  const s = subject || "VO Fraud Stop (Default)";
  const b = body || {};
  const text = [
    `Timestamp: ${b.timestamp || 'N/A'}`,
    `Institution: ${b.institution_name || 'N/A'}`,
    `Amount Stopped: ${b.amount_stopped !== undefined ? `${b.currency || ""} ${b.amount_stopped.toFixed(2)}` : 'N/A'}`,
    `Incident ID: ${b.incident_id || 'N/A'}`,
    `Hash Prefix: ${b.hash_prefix || 'N/A'}`,
    `Action: ${b.action || 'N/A'}`,
    `Flavor: ${b.apk_flavor || "web-citizen"}`, // Ensure APP_MODE is defined in client or passed
    `App Version: ${b.app_version || "web-1.0.0"}`, // Ensure APP_VERSION is defined in client or passed
    `Jurisdiction: ${b.jurisdiction || 'N/A'}`, // New field
    `Category: ${b.category || 'N/A'}`, // New field
  ].join("\n");

  try {
    await transporter.sendMail({
      from: `"Verum Omnis V2 Firewall" <no-reply@verumglobal.foundation>`,
      to: t, subject: s, text
    });
    logger.info("Fraud stop email dispatched", { to: t, subject: s });
  } catch (emailError) {
    logger.error("Failed to send fraud stop email:", emailError);
  }
}

// Change to onRequest from firebase-functions/v2/https, using its native Request/Response types
export const voEmailRelay = onRequest({ cors: true, maxInstances: 2 }, async (req: FunctionsRequest, res: FunctionsResponse) => {
  try {
    // Access req.method and req.body directly from functions v2 Request object
    if (req.method !== "POST") return res.status(405).send("Method Not Allowed");
    const { to, subject, body, idempotency_key } = req.body || {};
    if (!idempotency_key) return res.status(400).send("idempotency_key required");

    // Optional HMAC verify (if you choose to sign on-device)
    if (HMAC_SECRET && req.body.sig) { // Use req.body.sig
      const h = crypto.createHmac("sha256", HMAC_SECRET).update(JSON.stringify(req.body.body)).digest("base64"); // Use req.body.body
      if (h !== req.body.sig) { // Use req.body.sig
        logger.warn("Invalid HMAC signature received for email relay.");
        return res.status(401).send("Invalid signature");
      }
    }

    // Authenticate user and validate institution_id claim for this standalone function
    const authHeader = req.headers.authorization;
    let decodedToken: admin.auth.DecodedIdToken | undefined;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const idToken = authHeader.split('Bearer ')[1];
      try {
        decodedToken = await admin.auth().verifyIdToken(idToken);
      } catch (error) {
        logger.warn("Authentication: Error verifying ID token for email relay.", error);
        return res.status(403).send('Forbidden: Invalid token');
      }
    } else {
        logger.warn("Authentication: No Authorization header for email relay.");
        return res.status(401).send('Unauthorized: No token provided');
    }

    if (!decodedToken || !decodedToken.institution_id) {
        logger.warn("Unauthenticated or missing institution_id claim for email relay request.");
        return res.status(403).send("Forbidden: Authentication required with institution_id claim.");
    }
    // Assuming body will contain institution_id for validation
    if (decodedToken.institution_id !== body?.institution_id) { 
        logger.warn("Mismatched institution_id claim for email relay request.", { auth_institution_id: decodedToken.institution_id, payload_institution_id: body?.institution_id });
        return res.status(403).send("Forbidden: institution_id mismatch.");
    }


    // 1) Idempotency guard (Firestore)
    const docRef = db.collection("fraudStops").doc(String(idempotency_key));
    // Use a transaction for atomic read-then-write for idempotency (though create() also handles this)
    const snap = await docRef.get();
    if (snap.exists) {
      logger.info("Duplicate fraud stop event received (idempotent)", { idempotency_key });
      await maybeSendEmail(to, subject, body); // Optionally resend email, or just return OK
      return res.status(200).send({ ok: true, dedup: true });
    }

    const now = Date.now();
    const record = {
      incident_id: String(idempotency_key),
      auth_uid: decodedToken.uid, // Add authenticated user's UID from decoded token
      ts: body?.timestamp || new Date().toISOString(),
      institution: body?.institution_name || "Unknown",
      institution_id: decodedToken.institution_id, // Store institution ID from claim
      amount: Number(body?.amount_stopped || 0),
      currency: body?.currency || "USD",
      hash_prefix: body?.hash_prefix || "",
      action: body?.action || "FLAG",
      jurisdiction: body?.jurisdiction || null, // New field
      category: body?.category || null,       // New field
      apk_flavor: body?.apk_flavor || null,
      app_version: body?.app_version || null,
      received_at: now
    };

    // 2) Write operational doc to Firestore
    await docRef.set(record); // Use set() for create or update, it's simpler and idempotent for this use case

    // 3) Append to BigQuery
    const rows = [{
      received_date: new Date(now).toISOString().slice(0,10), // YYYY-MM-DD
      timestamp: record.ts,
      auth_uid: record.auth_uid,
      institution_name: record.institution,
      institution_id: record.institution_id,
      jurisdiction: record.jurisdiction,
      category: record.category,
      amount_stopped: record.amount,
      currency: record.currency,
      action: record.action,
      incident_id: record.incident_id,
      hash_prefix: record.hash_prefix,
      apk_flavor: record.apk_flavor,
      app_version: record.app_version
    }];
    await bq.dataset(DATASET).table(TABLE).insert(rows).catch(err=>{
      logger.error("BigQuery insert failed:", err);
      // Log the specific BigQuery error for debugging
      if (err.name === 'PartialFailureError' && err.errors && err.errors.length > 0) {
        err.errors.forEach((e: any) => logger.error("BigQuery row error:", e));
      }
    });

    // 4) Send email summary
    await maybeSendEmail(to, subject, body);

    return res.status(200).send({ ok: true });
  } catch (e: any) {
    logger.error("voEmailRelay error:", e);
    return res.status(500).send("Server error occurred during email dispatch or data storage.");
  }
});