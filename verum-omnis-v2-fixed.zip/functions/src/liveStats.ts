
import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { getApps, initializeApp } from "firebase-admin/app";
import * as logger from "firebase-functions/logger";

// Initialize Firebase Admin SDK only once
if (!getApps().length) {
  initializeApp();
}

const db = getFirestore();

export const updateLiveStats = onDocumentCreated("fraudStops/{incident_id}", async (event) => {
  const v = event.data?.data();
  if (!v) {
    logger.warn("No data found in fraudStops event for incident_id:", event.params.incident_id);
    return;
  }

  const institutionId = String(v.institution_id); // Use institution_id directly from the fraudStop record
  if (!institutionId || institutionId === 'undefined' || institutionId === 'null') {
    logger.warn("Missing or invalid institution_id in fraudStops event, cannot update live stats.", { incident_id: v.incident_id, raw_institution_id: v.institution_id });
    return;
  }
  
  // Directly reference the institution document using its ID
  const instDocRef = db.collection("institutions").doc(institutionId);
  const instSnap = await instDocRef.get();
  
  if (!instSnap.exists) {
    logger.warn("Institution document not found for fraudStops event, cannot update live stats.", { institutionId, incident_id: v.incident_id });
    // Optionally create a placeholder institution document or alert admin
    return; 
  }
  const instName = String(v.institution || "Unknown"); // Get name from the event data for logging/display

  const amount = Number(v.amount || 0);
  const now = new Date();
  const isoDate = now.toISOString().slice(0,10); // YYYY-MM-DD
  const statsRef  = instDocRef.collection("live").doc("stats");
  const recentRef = instDocRef.collection("live").doc("recent");

  try {
    await db.runTransaction(async (tx) => {
      // Update stats document
      const currentStats = (await tx.get(statsRef)).data() || {};

      const statsUpdate = {
        updated_at: now.getTime(),
        all_time_count: (currentStats.all_time_count || 0) + 1,
        all_time_amount: (currentStats.all_time_amount || 0) + amount,
        
        // Reset daily counters if day changes, otherwise increment
        today_count: isoDate === currentStats.last_day ? (currentStats.today_count || 0) + 1 : 1,
        today_amount: isoDate === currentStats.last_day ? (currentStats.today_amount || 0) + amount : amount,
        last_day: isoDate,
        
        last_60m_anchor: now.getTime(), // Client will use this to filter recent items
      };
      tx.set(statsRef, statsUpdate, { merge: true });

      // Update recent incidents list
      const recentDoc = (await tx.get(recentRef)).data() || { items: [] as any[] };
      const head = {
        ts: v.ts || v.timestamp,
        incident_id: v.incident_id,
        amount: amount,
        currency: v.currency || "USD",
        action: v.action || "FLAG",
        category: v.category || null,
        hash_prefix: v.hash_prefix || ""
      };
      const items = [head, ...(recentDoc.items || [])].slice(0, 50); // Keep last 50 incidents
      tx.set(recentRef, { items, updated_at: now.getTime() }, { merge: true });
    });
    logger.info("Live stats updated for institution:", { institutionId, instName, incident_id: v.incident_id });
  } catch (error) {
    logger.error("Error updating live stats for incident:", { incident_id: v.incident_id, error });
  }
});