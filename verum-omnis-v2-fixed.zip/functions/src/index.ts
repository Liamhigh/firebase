
import { onRequest } from 'firebase-functions/v2/https';
import express, { Request, Response, NextFunction } from 'express'; // Import types directly from 'express'
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { assistantRouter } from './routes/assistant';
import { voEmailRelay } from './emailRelay';
import { updateLiveStats } from './liveStats';
import { voRetailRelay } from './retailRelay'; // Import the new retail relay
import * as logger from 'firebase-functions/logger';
import * as admin from 'firebase-admin'; // Import firebase-admin

// Extend Request type to include user
declare global {
  namespace Express {
    interface Request {
      user?: admin.auth.DecodedIdToken;
    }
  }
}

// Initialize Firebase Admin SDK only once
if (!admin.apps.length) {
  admin.initializeApp();
}

const app = express();

// Middleware to authenticate Firebase users
const authenticateUser = async (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    logger.warn("Authentication: No Authorization header or malformed.");
    return res.status(401).send('Unauthorized');
  }

  const idToken = authHeader.split('Bearer ')[1];
  try {
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    req.user = decodedToken; // Attach user to request
    next();
  } catch (error) {
    logger.error("Authentication: Error verifying ID token.", error);
    res.status(403).send('Forbidden');
  }
};


// Security Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      // Ensure cdn.jsdelivr.net is allowed for scripts for pdf-lib and qrcode
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net", "https://www.gstatic.com", "https://firestore.googleapis.com", "https://securetoken.googleapis.com", "https://www.google.com"], // Allow Firebase client SDKs and Firestore for modules
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      imgSrc: ["'self'", "data:", "https://www.gstatic.com", "https://www.google.com"], 
      mediaSrc: ["'self'", "blob:"], // Allow blob for audio/video playback if needed
      fontSrc: ["'self'", "https://fonts.googleapis.com", "https://fonts.gstatic.com"], // If any fonts are loaded from Google Fonts
      connectSrc: ["'self'", "https://*.googleapis.com", "https://*.web.app", "https://*.firebaseapp.com", "https://firestore.googleapis.com", "https://securetoken.googleapis.com", "https://identitytoolkit.googleapis.com", "https://www.googleapis.com", "https://www.google.com"], // Allow Google APIs for AI calls and Firebase Hosting domains, and Firestore, and Firebase Auth
      childSrc: ["'self'", "blob:"], // Allow blob for Web Speech API if it uses iframes/workers
      workerSrc: ["'self'", "blob:"], // Allow blob for Web Speech API workers
    },
  },
}));
app.use(cors({ origin: true }));
app.use(express.json({ limit: "1mb" }));

// Rate Limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per 15 minutes
  message: 'Too many requests from this IP, please try again after 15 minutes',
});
// Apply apiLimiter as Express middleware
app.use(apiLimiter);

// Apply authentication middleware to all /api routes
app.use('/api', authenticateUser); // Apply authenticateUser only to paths starting with /api

// Routes
app.use('/api/assistant', assistantRouter); // Mount assistantRouter under /api/assistant

// Placeholder /verify endpoint
app.post('/api/verify', (req: Request, res: Response) => {
  const { sha512_prefix } = req.body; // Only log/handle prefixes for privacy
  if (typeof sha512_prefix !== 'string' || sha512_prefix.length < 5 || sha512_prefix.length > 128) {
    return res.status(400).json({ error: 'Invalid SHA-512 prefix format.' });
  }
  logger.info(`Verification request for hash prefix: ${sha512_prefix.substring(0, 12)}...`, { uid: req.user?.uid });
  res.status(200).json({ ok: true, sha512_prefix: sha512_prefix });
});

// Placeholder /seal endpoint (server-side sealing fallback, not logging content)
app.post('/api/seal', (req: Request, res: Response) => {
  const { sha512_prefix } = req.body; // Expecting a hash of the content, not the content itself
  if (typeof sha512_prefix !== 'string' || sha512_prefix.length < 5) {
    return res.status(400).json({ error: 'Invalid SHA-512 prefix for sealing.' });
  }
  logger.info(`Server-side sealing request for hash prefix: ${sha512_prefix.substring(0, 12)}...`, { uid: req.user?.uid });
  // Simulate a server-side sealed PDF
  const base64Placeholder = 'JVBERi0xLjQKJdDUxdgKMSAwIG9iagogIDwvc2VlIEZBTFNFIC9UeXBlIC9DYXRhbG9nIC9QYWdlcyAyIDAgUiAvVmVyc2lvbiAvTmFtZXMgMCBhIDQ2IGUgc2UgZmluYWwgZGUgY2FkZW5hIC8+Cg=='
  res.status(200).json({ success: true, message: 'Server-side sealing completed (placeholder).', sealedPdfBase64: base64Placeholder });
});

// Simple health check endpoint
app.get('/api/health', (req: Request, res: Response) => {
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString(), uid: req.user?.uid });
});

// Export the Express app directly using functions.v2.https.onRequest
// FIX: Changed CommonJS 'exports.api' to ES Module 'export const api' to match module syntax.
export const api = onRequest(app);

// Export the new email relay function
export { voEmailRelay };

// Export the new live stats function
export { updateLiveStats };

// Export the new retail relay function
export { voRetailRelay };
