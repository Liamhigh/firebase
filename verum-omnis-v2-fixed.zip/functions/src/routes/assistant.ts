
import express, { Request, Response } from 'express'; // Import specific types from 'express'
import { GoogleGenAI } from '@google/genai';
import * as functions from 'firebase-functions';
import OpenAI from 'openai';
import * as admin from 'firebase-admin';
// FIX: Import Buffer to resolve TypeScript error in Node.js environment.
import { Buffer } from 'buffer';

const assistantRouter = express.Router();

// Initialize GoogleGenAI within the function scope or when the module is loaded
// This ensures process.env.API_KEY is available during Firebase Function execution.
if (!process.env.API_KEY) {
  functions.logger.error("API_KEY environment variable not set for GoogleGenAI.");
}
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string }); // Ensure API_KEY is cast to string

// Initialize OpenAI client
if (!process.env.OPENAI_API_KEY) {
  functions.logger.error("OPENAI_API_KEY environment variable not set for OpenAI.");
}
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY as string });

const triageSystemInstruction = `You are a legal AI assistant for Verum Omnis V2, operating under the principles of the Verum Omnis V2 Constitution. Your role is to act as a persistent legal counsel.
You must:
1. Provide clear, direct, and actionable legal guidance in plain language based on the user-provided information, attached documents, and the full conversation history.
2. Be concise. Get straight to the point. Do not use filler phrases or unnecessary disclaimers. Your responses are considered legal advice under the Verum Omnis V2 protocol.
3. If it is strategically sound, you may suggest in natural language that the user seal the transcript for their records.
4. Do not log or store user data externally; your entire context is within this conversation. All forensics are client-side.
`;

// --- Triple-AI Provider Implementations ---

async function callGemini(contents: any[], systemInstruction: string, location: {latitude: number, longitude: number} | null): Promise<string> {
  try {
    let dynamicSystemInstruction = systemInstruction;
    if (location) {
      dynamicSystemInstruction += `\n\nCRITICAL CONTEXT: The user's current location is latitude ${location.latitude}, longitude ${location.longitude}. Use this for jurisdiction-specific legal analysis. Do not mention the coordinates in your response.`;
    }

    // The 'contents' field for generateContent expects an array of parts directly.
    // 'contents' is already constructed as an array of parts.
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents, // This is already an array of parts
      config: {
        systemInstruction: dynamicSystemInstruction,
      }
    });
    return response.text;
  } catch (error) {
    functions.logger.error("Error calling Gemini API:", error);
    return "Error: Could not connect to the Gemini consensus engine.";
  }
}

async function callDeepSeek(prompt: string, contents: any[]): Promise<string> {
  // This is a stub as requested.
  // In a real scenario, this would involve calling the DeepSeek API with multimodal contents if supported.
  functions.logger.info(`DeepSeek stub received prompt: ${prompt.substring(0, 50)}... and ${contents.length > 1 ? 'file' : 'no file'}`);
  return new Promise(resolve => setTimeout(() => resolve(`DeepSeek Analysis Stub: The query concerns established legal precedents. Recommend reviewing similar case files for comparative analysis. The user should focus on the chain of custody for digital evidence.`), 200));
}

async function callOpenAI(contents: any[], systemInstruction: string, location: {latitude: number, longitude: number} | null): Promise<string> {
  try {
    let currentSystemInstruction = systemInstruction;
    if (location) {
        currentSystemInstruction += `\n\nCRITICAL CONTEXT: The user's current location is latitude ${location.latitude}, longitude ${location.longitude}. Use this for jurisdiction-specific legal analysis. Do not mention the coordinates in your response.`;
    }

    const openaiMessages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: "system", content: currentSystemInstruction }
    ];

    let userContentParts: OpenAI.Chat.Completions.ChatCompletionContentPart[] = [];

    // Assuming the first part is always text from the prompt
    if (contents.length > 0 && contents[0].text) {
        userContentParts.push({ type: "text", text: contents[0].text });
    }

    // Process additional parts (e.g., files)
    for (let i = 1; i < contents.length; i++) {
        const part = contents[i];
        if (part.inlineData) {
            const filePart = part.inlineData;
            if (filePart.mimeType.startsWith('image/')) {
                userContentParts.push({
                    type: "image_url",
                    image_url: { url: `data:${filePart.mimeType};base64,${filePart.data}` }
                });
            } else {
                // For non-image files, note them in the text
                userContentParts.push({ type: "text", text: `(Attached file: ${filePart.name || 'unknown'}. Type: ${filePart.mimeType}. Content not directly processed by vision model.)` });
                // If it's a text file, try to extract and add it
                if (filePart.mimeType.startsWith('text/')) {
                    try {
                        const decodedText = Buffer.from(filePart.data, 'base64').toString('utf8');
                        userContentParts.push({ type: "text", text: `--- Document Content ---\n${decodedText}\n--- End Document ---` });
                    } catch (decodeError) {
                        functions.logger.warn(`Failed to decode text file for OpenAI: ${decodeError}`);
                    }
                }
            }
        }
    }
    
    openaiMessages.push({ role: "user", content: userContentParts });

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // Using a multimodal model
      messages: openaiMessages,
      max_tokens: 1000,
    });
    return response.choices[0].message.content || "Error: OpenAI returned no content.";
  } catch (error) {
    functions.logger.error("Error calling OpenAI API:", error);
    return "Error: Could not connect to the OpenAI consensus engine.";
  }
}

function buildConsensus(parts: string[]): string {
    // Prioritize Gemini, then OpenAI, then DeepSeek
    // This maintains directness, but offers fallbacks.
    if (parts[0] && !parts[0].includes("Error:")) return parts[0]; // Gemini
    if (parts[1] && !parts[1].includes("Error:")) return parts[1]; // OpenAI
    if (parts[2] && !parts[2].includes("Error:")) return parts[2]; // DeepSeek

    // If all are errors, return a generic error message
    return "All AI engines encountered an issue. Please try again later.";
}

assistantRouter.post('/', async (req: Request, res: Response) => {
  const { prompt, context, mode, location, file } = req.body;

  if (!prompt && !file) {
    return res.status(400).json({ error: 'Prompt or file must be provided.' });
  }

  try {
    // Access authenticated user UID
    const authUid = req.user?.uid;
    if (!authUid) {
      functions.logger.warn("Unauthorized API call to /assistant (no UID).");
      return res.status(401).json({ error: "Unauthorized: Authentication required." });
    }
    functions.logger.info(`Assistant API call by user: ${authUid}`);


    let geminiContents: any[] = [{ text: prompt }];
    let openaiContentsForCall: any[] = [{ text: prompt }]; // Prepare for OpenAI call

    if (file) {
      const previewableImageMimeTypes = [
        'image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif',
      ];
      const previewableDocumentMimeTypes = [
        'application/pdf', // Gemini can process PDFs
        'text/plain', 'text/markdown', 'application/json', 'application/xml', // Text formats
      ];
      
      // For Gemini, send all supported files as inlineData
      if (previewableImageMimeTypes.includes(file.mimeType) || previewableDocumentMimeTypes.includes(file.mimeType) || file.mimeType.startsWith('text/')) {
        geminiContents.push({ inlineData: { mimeType: file.mimeType, data: file.data, name: file.name } });
      } else {
        // For other non-previewable files by Gemini via inlineData, append a note
        geminiContents[0].text = `${prompt}\n\n[Attached non-previewable file: ${file.name}. Its content might not be fully analyzed.]`;
        geminiContents.push({ inlineData: { mimeType: file.mimeType, data: file.data, name: file.name } }); // Still send data, Gemini might try to use it.
      }

      // For OpenAI, prepare contents according to callOpenAI's expectations
      // callOpenAI expects a structured contents array, similar to Gemini
      openaiContentsForCall.push({ inlineData: { mimeType: file.mimeType, data: file.data, name: file.name } });
    }

    const [geminiRes, openaiRes, deepseekRes] = await Promise.all([
        callGemini(geminiContents, triageSystemInstruction, location),
        callOpenAI(openaiContentsForCall, triageSystemInstruction, location),
        callDeepSeek(prompt, geminiContents), // DeepSeek still a stub, passing contents
    ]);
    
    const rawParts = [
        { provider: 'Gemini', text: geminiRes },
        { provider: 'OpenAI', text: openaiRes },
        { provider: 'DeepSeek', text: deepseekRes },
    ];

    const consensus = buildConsensus([geminiRes, openaiRes, deepseekRes]);
    
    res.status(200).json({ text: consensus, rawParts });

  } catch (error) {
    functions.logger.error("Error in Triple-AI orchestration:", error);
    res.status(500).json({ error: "An error occurred while processing your request with the AI consensus engine." });
  }
});

export { assistantRouter };
