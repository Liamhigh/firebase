# Verum Omnis V2 Deployment Guide

This document outlines the steps to deploy the Verum Omnis V2 web application to Firebase Hosting and Functions.

## 1. Firebase Project Setup

If you haven't already, set up your Firebase project:

1.  **Install Firebase CLI:**
    ```bash
    npm install -g firebase-tools
    ```
2.  **Login to Firebase:**
    ```bash
    firebase login
    ```
3.  **Initialize your project (if new):**
    Navigate to your `verum-omnis/` root directory and run:
    ```bash
    firebase init
    ```
    *   Select "Functions", "Hosting".
    *   For Functions, choose TypeScript, use Node.js 20, and install dependencies.
    *   For Hosting public directory, specify `web` (this is where the static HTML/JS app is located).
    *   Configure as a single-page app: `No` (since we have two distinct HTML pages, Firebase will serve them directly based on `firebase.json` rewrites/redirects).
4.  **Link to your Firebase Project:**
    Ensure your `.firebaserc` file in the root directory contains your Firebase project ID. If `firebase init` didn't set it correctly, manually update `default` to your project ID:
    ```json
    {
      "projects": {
        "default": "YOUR_FIREBASE_PROJECT_ID"
      }
    }
    ```
5.  **Set Google Gemini API Key:**
    The AI functions require an API key. Set this as a Firebase Function environment variable:
    ```bash
    firebase functions:config:set genai.api_key="YOUR_GEMINI_API_KEY"
    ```
    Verify it's set:
    ```bash