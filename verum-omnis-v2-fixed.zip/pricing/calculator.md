# Verum Omnis V2 Retail Security Pricing Guide

This document outlines the pricing structure and ROI calculations for the Verum Omnis V2 Retail Security Suite, designed for retail/petrol forecourts and branch operations.

---

## 1) Pricing Model (Rules of Thumb)

Our pricing is designed to be transparent, scalable, and directly tied to the value we provide in preventing fraud and enhancing operational security.

*   **Per Lane Monitoring**: `$79–$129 / lane / month`
    *   Includes comprehensive CCTV and POS fusion analytics for a single cashier lane. This covers cashier skims, scan/price swaps, no-sale skims, refund fraud, and bagging bypass.
    *   **Includes Cigarette/Lotto Cabinet Monitoring** where applicable within the lane's scope.

*   **Forecourt Add-on (Per Pump Camera)**: `$49 / pump camera / month`
    *   Adds dedicated monitoring for fuel pump anomalies, including authorization misses, split-tender tricks, and micro-authorizations. Requires a dedicated camera for the pump area.

*   **Per Door Sensor (Access Sentinel)**: `$15–$25 / door / month`
    *   Integrates physical door sensor data (e.g., reed sensors) to detect unauthorized back-door access, unusual entry/exit patterns, and after-hours activity. Enhances overall site security.

*   **Site Platform Fee**: `$99 / site / month`
    *   A base fee per retail site. This includes access to the live scoreboard, incident sealing capabilities, and standard reporting features.

*   **Outcome Bonus (Optional)**: `0.5–2.0 bps of audited prevented loss`
    *   For clients opting into a performance-based pricing tier, a small basis point (bps) fee is applied to the documented and audited financial losses prevented by Verum Omnis V2. This aligns our incentives directly with the customer's financial gains.

---

## 2) Multi-Site & Chain Discounts

*   Special tiered discounts are available for multi-site operators and retail chains. Please contact our sales team for a custom quote.

---

## 3) ROI and Value Proposition

Verum Omnis V2 delivers rapid ROI by:

*   **Directly Reducing Shrinkage**: Identifying and flagging various forms of retail fraud in real-time.
*   **Deterrence**: The presence of advanced AI monitoring deters fraudulent activities.
*   **Operational Efficiency**: Automating incident detection frees up management time from manual review.
*   **Enhanced Auditability**: Providing sealed, court-ready incident reports with cryptographic proofs.

---

## 4) Get Started

Contact our sales team to schedule a demo, discuss your specific needs, and obtain a personalized quote for your retail operations.