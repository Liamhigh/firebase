// web/js/rule-engine.js
import * as OP from './logic/ops.js';
function evalCond(c,ctx){
  const a=ctx[c.field];
  const b=c.ref?ctx[c.ref]:c.value;
  const fn=OP[c.op];
  if(!fn) throw `Unknown op ${c.op}`;
  return fn(a,b,c,ctx);
}
function evalNode(n,ctx){
  if(n.type==='all') return n.conditions.every(c=>evalCond(c,ctx));
  if(n.type==='any') return n.conditions.some(c=>evalCond(c,ctx));
  throw `Unknown node type: ${n.type}`;
}
export function evaluateRule(rule,ctx){
  try {
    const pass=evalNode(rule.logic,ctx);
    return {id:rule.id,brain:rule.brain,pass,severity:rule.severity,action:rule.action,recovery:rule.recovery||[]};
  } catch (error) {
    console.error(`Error evaluating rule ${rule.id}: ${error.message}`);
    return {id:rule.id,brain:rule.brain,pass:false,severity:"ERROR",action:"RULE_EVAL_FAILED",recovery:[]};
  }
}