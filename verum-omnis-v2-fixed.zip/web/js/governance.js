
// web/js/governance.js
import { evaluateRule } from './rule-engine.js';
import { vaultAppend } from './vault.js'; // Import vaultAppend

const sevScore={CRITICAL:1.0,HIGH:0.8,MEDIUM:0.5,LOW:0.3,ERROR:0.0};
const toClaim=a=>a; // Simple passthrough, can be expanded for complex claim mapping

function synthesize(ballots){
  const tally={};
  for(const b of ballots){
    tally[b.claim]=(tally[b.claim]||0)+b.score;
  }
  const ranked=Object.entries(tally).sort((a,b)=>b[1]-a[1]);
  const [claim,weight]=ranked[0]||['NO_ACTION',0.0]; // Default to NO_ACTION if no claims or all scores are 0
  const totalScore = Object.values(tally).reduce((sum, score) => sum + score, 0);

  return {
    claim,
    confidence: Math.min(1, weight / Math.max(1, totalScore)), // Confidence based on winning claim's weight vs total score
    quorum: ballots.length,
    ranked // All ranked claims for transparency
  };
}

// New function to enqueue fraud email, now accepting more context
async function enqueueFraudEmail({institution_name, amount, currency, incident_id, hash_prefix, action, jurisdiction, category}) {
  const payload = {
    to: "documents@verumglobal.foundation",
    subject: `VO Fraud Stop — ${institution_name} — ${currency || ''}${amount}`,
    body: {
      timestamp: new Date().toISOString(),
      institution_name, amount_stopped: amount, currency,
      incident_id, hash_prefix, action,
      apk_flavor: window.APP_MODE || "web-citizen", // Use window.APP_MODE
      app_version: window.APP_VERSION || "web-1.0.0", // Use window.APP_VERSION
      jurisdiction: jurisdiction || null, // New field
      category: category || null, // New field
    },
    idempotency_key: incident_id
  };
  await vaultAppend({ t: payload.body.timestamp, type:"email_queue", payload });
}

// New function to enforce actions based on final governance decision
export async function enforceAction(final, ctx) {
  // ... your existing WARN/FLAG/FREEZE/ESCALATE handling ...

  // Institutions email trigger:
  const instMode = (window.APP_MODE === 'institution');
  const stopping = (final.claim === 'FLAG_AND_FREEZE' || final.claim === 'ESCALATE_ANOMALY' || final.claim === 'FLAG'); // Also trigger for 'FLAG'
  
  if (instMode && stopping && typeof ctx.amount === 'number' && ctx.amount > 0) { // Ensure amount is a positive number
    await enqueueFraudEmail({
      institution_name: ctx.institution_name || "Unknown Institution",
      amount: ctx.amount,
      currency: ctx.currency || "USD",
      incident_id: ctx.incident_id || `INST-${Date.now().toString(36).toUpperCase()}`, // Generate a simple incident ID
      hash_prefix: (ctx.document_hash || "").slice(0,12),
      action: final.claim,
      jurisdiction: ctx.jurisdiction || null, // Pass new field
      category: ctx.category || null, // Pass new field
    });
  }
}

export function runGovernance(ctx, giftRules){
  const hits = giftRules.rules.map(r=>evaluateRule(r,ctx)).filter(r=>r.pass);
  const ballots = hits.map(h=>({id:h.brain,claim:toClaim(h.action),score:sevScore[h.severity]||0.4,rationale:h.id}));

  // B9_RnD_Advisory for anomaly detection
  if (ctx.anomaly_score > (ctx.threshold || 0.7)) {
    ballots.push({id:'B9_RnD_Advisory',claim:'ESCALATE_ANOMALY',score:0.6,rationale:'rnd-advisory-high-anomaly'});
  }

  const finalDecision = synthesize(ballots);

  // Call enforceAction here after synthesizing the final decision
  // We'll pass ctx which contains context for the action
  enforceAction(finalDecision, ctx);

  return {ballots, final: finalDecision};
}