// chat.js
// This script handles all client-side interactions for the chat.html page.

// --- Import Governance Modules ---
import { loadGiftRules } from './rules-loader.js';
import { runGovernance, enforceAction } from './governance.js'; // Import enforceAction
import { vaultAppend } from './vault.js';
// --- Import Auth Module ---
import { auth, onAuthStateChanged, signOutUser, signInWithEmail, signInWithGoogle, getAuthErrorMessage, getCurrentUserClaims } from './auth.js';


// --- Global Type Definitions (for clarity in vanilla JS) ---
/**
 * @typedef {object} ChatMessage
 * @property {string} id
 * @property {'user' | 'model' | 'system'} role
 * @property {string} text
 * @property {{provider: string; text: string}[]} [rawResponses]
 * @property {{name: string; size: number; mimeType: string;}} [attachment]
 */

/**
 * @typedef {object} EvidenceFile
 * @property {string} name
 * @property {string} sha512
 * @property {File} file
 * @property {number} size
 * @property {string} mimeType
 */

/**
 * @typedef {object} SealedPackage
 * @property {string} name
 * @property {string} sha512
 * @property {string} createdAt
 * @property {string} [manifestText] // For the manifest itself, before sealing to PDF
 */

/**
 * @typedef {object} Geolocation
 * @property {number} latitude
 * @property {number} longitude
 */

// --- DOM Elements ---
const promptInput = document.getElementById('prompt-input');
const chatForm = document.getElementById('chat-form');
const chatMessages = document.getElementById('chat-messages');
const askBtn = document.getElementById('ask-btn');
const attachFileBtn = document.getElementById('attach-file-btn');
const chatFileInput = document.getElementById('chat-file-input');
const attachedFileDisplay = document.getElementById('attached-file-display');
const attachedFileName = document.getElementById('attached-file-name');
const attachedFileDetails = document.getElementById('attached-file-details'); // New element
const fileProgressDiv = document.getElementById('file-progress'); // New element
const fileProgressBar = fileProgressDiv ? fileProgressDiv.querySelector('div') : null; // New element
const removeAttachedFileBtn = document.getElementById('remove-attached-file-btn');
const sealTranscriptBtn = document.getElementById('seal-transcript-btn');
const printTranscriptBtn = document.getElementById('print-transcript-btn');
const modeLabel = document.getElementById('mode-label');

// Auth UI Elements
const authButton = document.getElementById('auth-button');
const userEmailDisplay = document.getElementById('user-email-display');
const loginModal = document.getElementById('login-modal');
const closeModalBtn = loginModal ? loginModal.querySelector('.modal-close-btn') : null;
const emailLoginForm = document.getElementById('email-login-form');
const googleLoginBtn = document.getElementById('google-login-btn');
const authErrorMessage = document.getElementById('auth-error-message');


// Verifier Panel Elements
const sha512Input = document.getElementById('sha512-input');
const verifyHashBtn = document.getElementById('verify-hash-btn');
const fileUploadInput = document.getElementById('file-upload');
const fileUploadText = document.getElementById('file-upload-text');
const verificationStatusDiv = document.getElementById('verification-status');
const evidenceLockerDiv = document.getElementById('evidence-locker');
const evidenceListDiv = document.getElementById('evidence-list');
const sealEvidenceBundleBtn = document.getElementById('seal-evidence-bundle-btn');

// Sealed Packages Panel Elements
const sealedPackagesPanel = document.getElementById('sealed-packages-panel');
const sealedPackagesList = document.getElementById('sealed-packages-list');

// Status Panel Elements
const statusIndicator = document.getElementById('status-indicator');
const statusText = document.getElementById('status-text');
const healthBtn = document.getElementById('healthBtn');
const lastCheckP = document.getElementById('last-check');

// Voice Input Elements
const voiceInputToggleBtn = document.getElementById('voice-input-toggle');

// Analysis Panel Elements (for 'tax' mode)
const analysisPanel = document.getElementById('analysis-panel');
const analysisContent = document.getElementById('analysis-content');
const runAnalysisBtn = document.getElementById('run-analysis-btn');
const analysisPromptText = document.getElementById('analysis-prompt-text');

// Nine-Brain Governance Elements
const governancePanel = document.getElementById('governance-panel');
const nineBrainPanel = document.getElementById('nine-brain-panel');
const finalDecisionPanel = document.getElementById('final-decision-panel');
const finalClaim = document.getElementById('final-claim');
const finalConfidence = document.getElementById('final-confidence');


// --- Global State ---
/** @type {ChatMessage[]} */
let messages = [];
let isLoading = false;
/** @type {File | null} */
let attachedFile = null;
let fileProcessingProgress = 0; // New state for file processing progress
/** @type {Geolocation | null} */
let currentLocation = null;
/** @type {EvidenceFile[]} */
let evidenceFiles = [];
/** @type {SealedPackage[]} */
let sealedPackages = [];
let isListening = false;
let recognition = null; // SpeechRecognition object
let giftRules = null; // Loaded governance rules
let currentUser = null; // Firebase User object


const DB_NAME = 'VerumOmnisV2DB';
const DB_VERSION = 1;
const MESSAGES_STORE_NAME = 'messages';
const EVIDENCE_STORE_NAME = 'evidence';
const PACKAGES_STORE_NAME = 'packages';

// --- IndexedDB Service ---
class StorageService {
    constructor() {
        this.dbPromise = this._initDb();
    }

    _initDb() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);

            request.onerror = () => {
                console.error('IndexedDB error:', request.error);
                reject(request.error);
            };

            request.onsuccess = () => {
                resolve(request.result);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains(MESSAGES_STORE_NAME)) {
                    db.createObjectStore(MESSAGES_STORE_NAME, { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains(EVIDENCE_STORE_NAME)) {
                    db.createObjectStore(EVIDENCE_STORE_NAME, { keyPath: 'sha512' });
                }
                if (!db.objectStoreNames.contains(PACKAGES_STORE_NAME)) {
                    db.createObjectStore(PACKAGES_STORE_NAME, { keyPath: 'sha512' });
                }
            };
        });
    }

    async saveItems(storeName, items) {
        const db = await this.dbPromise;
        const transaction = db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        store.clear();
        items.forEach(item => {
            store.put(item);
        });
        return new Promise((resolve, reject) => {
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
        });
    }

    async loadItems(storeName) {
        const db = await this.dbPromise;
        const transaction = db.transaction(storeName, 'readonly');
        const store = transaction.objectStore(storeName);
        const request = store.getAll();
        return new Promise((resolve, reject) => {
            request.onsuccess = () => {
                // Sort messages by ID (which is timestamp for chat)
                if (storeName === MESSAGES_STORE_NAME) {
                    const sorted = request.result.sort((a, b) => {
                        const idA = a.id === 'initial' ? 0 : parseInt(a.id, 10);
                        const idB = b.id === 'initial' ? 0 : parseInt(b.id, 10);
                        return idA - idB;
                    });
                    resolve(sorted);
                } else if (storeName === PACKAGES_STORE_NAME) {
                    const sorted = request.result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
                    resolve(sorted);
                }
                else {
                    resolve(request.result);
                }
            };
            request.onerror = () => reject(request.error);
        });
    }
}
const storageService = new StorageService();


// --- UI Utility Functions ---
const scrollToBottom = () => {
    // Only scroll if the user is near the bottom
    const isAtBottom = chatMessages.scrollHeight - chatMessages.clientHeight <= chatMessages.scrollTop + 50; // 50px buffer
    if (isAtBottom) {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
};

/**
 * Adds a message to the chat display.
 * @param {ChatMessage} msg
 */
const addMessageToDisplay = (msg) => {
    const msgDiv = document.createElement('div');
    msgDiv.className = `chat-message-wrapper chat-message-${msg.role}`;

    const contentDiv = document.createElement('div');
    contentDiv.className = `chat-message-content`;
    
    // Add role heading for clarity, especially in print
    const roleHeading = document.createElement('strong');
    roleHeading.textContent = msg.role === 'user' ? 'You:' : msg.role === 'model' ? 'Assistant:' : 'System:';
    contentDiv.appendChild(roleHeading);

    const messageText = document.createElement('p');
    messageText.className = 'text-sm whitespace-pre-wrap';
    messageText.innerHTML = msg.text; // Use innerHTML for Markdown rendering if needed later, otherwise textContent
    contentDiv.appendChild(messageText);

    // Copy to Clipboard Button
    const copyButtonWrapper = document.createElement('div');
    copyButtonWrapper.className = `absolute top-0 right-0 transform -translate-y-1/2 translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200`;
    
    const copyButton = document.createElement('button');
    copyButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" class="w-4 h-4"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 17.25V21h-9.75A2.25 2.25 0 0 1 3 18.75V7.5A2.25 2.25 0 0 1 5.25 5.25H9M15.75 17.25v-4.75m0 4.75H12m3.75 0h4.5a2.25 2.25 0 0 0 2.25-2.25V6.75A2.25 2.25 0 0 0 20.25 4.5H12A2.25 2.25 0 0 0 9.75 6.75v3M15.75 17.25h-4.5" /></svg>`;
    copyButton.className = "bg-gray-800 p-1 rounded-full text-gray-300 hover:bg-gray-600 hover:text-white shadow-md";
    copyButton.setAttribute('aria-label', 'Copy message to clipboard');
    copyButton.onclick = async () => {
        try {
            await navigator.clipboard.writeText(msg.text);
            const copiedFeedback = document.createElement('span');
            copiedFeedback.className = "bg-green-600 text-white px-2 py-1 rounded-full text-xs shadow-md";
            copiedFeedback.textContent = "Copied!";
            copyButtonWrapper.replaceChild(copiedFeedback, copyButton);
            setTimeout(() => {
                copyButtonWrapper.replaceChild(copyButton, copiedFeedback);
            }, 1500);
        } catch (err) {
            console.error('Failed to copy text: ', err);
            alert('Failed to copy text.');
        }
    };
    copyButtonWrapper.appendChild(copyButton);
    contentDiv.classList.add('group', 'relative'); // Add group for hover, relative for absolute button
    contentDiv.appendChild(copyButtonWrapper);


    if (msg.attachment) {
        const attachmentDiv = document.createElement('div');
        attachmentDiv.className = "chat-message-attachment";
        attachmentDiv.innerHTML = `
            <p class="font-semibold text-blue-100 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" class="w-3 h-3 icon-space inline-block"><path strokeLinecap="round" strokeLinejoin="round" d="m18.375 12.739-7.693 7.693a4.5 4.5 0 0 1-6.364-6.364l10.94-10.94A3 3 0 1 1 19.5 7.372L8.552 18.32m.009-.01-.01.01m5.699-9.941-7.81 7.81a1.5 1.5 0 0 0 2.122 2.122l7.81-7.81" /></svg>
                Attached: ${msg.attachment.name} (${window.formatBytes(msg.attachment.size)}, ${msg.attachment.mimeType})
            </p>
        `;
        contentDiv.appendChild(attachmentDiv);
    }

    if (msg.rawResponses && msg.rawResponses.length > 0) {
        const details = document.createElement('details');
        details.className = "chat-message-raw-responses";
        details.innerHTML = `
            <summary class="cursor-pointer text-gray-400">View Triple-AI Raw Responses</summary>
            <div class="mt-2 space-y-2 border-t border-gray-600 pt-2">
                ${msg.rawResponses.map(res => `
                    <div>
                        <p class="font-bold text-gray-300">${res.provider}:</p>
                        <p class="sub-text text-gray-400">${res.text}</p>
                    </div>
                `).join('')}
            </div>
        `;
        contentDiv.appendChild(details);
    }

    msgDiv.appendChild(contentDiv);
    chatMessages.appendChild(msgDiv);
    scrollToBottom();
};

const showLoadingIndicator = () => {
    const loadingDiv = document.createElement('div');
    loadingDiv.id = 'loading-indicator';
    loadingDiv.className = "loading-indicator-wrapper";
    loadingDiv.innerHTML = `
        <div class="loading-indicator-content">
            <div class="loading-indicator-dot"></div>
            <div class="loading-indicator-dot delay-75"></div>
            <div class="loading-indicator-dot delay-150"></div>
        </div>
    `;
    chatMessages.appendChild(loadingDiv);
    scrollToBottom();
};

const hideLoadingIndicator = () => {
    const loadingDiv = document.getElementById('loading-indicator');
    if (loadingDiv) {
        loadingDiv.remove();
    }
};

const updateModeLabel = (mode) => {
    if (mode && mode !== 'chat') {
        modeLabel.textContent = `Mode: ${mode.charAt(0).toUpperCase() + mode.slice(1)}`;
        modeLabel.classList.remove('hidden');
    } else {
        modeLabel.classList.add('hidden');
    }
};

/**
 * Updates the display of evidence files in the Forensic Firewall panel.
 */
const updateEvidenceLockerDisplay = () => {
    if (evidenceFiles.length === 0) {
        evidenceLockerDiv.classList.add('hidden');
        return;
    }
    evidenceLockerDiv.classList.remove('hidden');
    evidenceListDiv.innerHTML = ''; // Clear existing list
    evidenceFiles.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.className = "text-xs font-mono bg-gray-900/50 p-2 rounded";
        itemDiv.innerHTML = `
            <p class="text-gray-200 truncate" title="${item.name}">${item.name}</p>
            <p class="text-gray-400 text-[10px] mt-1">${window.formatBytes(item.size)} (${item.mimeType})</p>
            <p class="text-green-400 break-all text-[10px]">${item.sha512}</p>
        `;
        evidenceListDiv.appendChild(itemDiv);
    });
};

/**
 * Updates the display of sealed packages in the Sealed Packages panel.
 */
const updateSealedPackagesDisplay = () => {
    if (sealedPackages.length === 0) {
        sealedPackagesPanel.classList.add('hidden');
        return;
    }
    sealedPackagesPanel.classList.remove('hidden');
    sealedPackagesList.innerHTML = ''; // Clear existing list
    sealedPackages.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).forEach(pkg => {
        const pkgDiv = document.createElement('div');
        pkgDiv.className = "bg-gray-800 p-3 rounded-lg";
        pkgDiv.innerHTML = `
            <div class="flex items-center justify-between">
              <div class="flex items-center text-green-400">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" class="w-5 h-5 icon-space"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" /></svg>
                <p class="text-sm font-semibold text-gray-200 truncate" title="${pkg.name}">
                  ${pkg.name}
                </p>
              </div>
              <button
                data-hash="${pkg.sha512}"
                data-name="${pkg.name}"
                data-created="${pkg.createdAt}"
                data-manifest="${pkg.manifestText ? btoa(encodeURIComponent(pkg.manifestText)) : ''}"
                class="download-package-btn btn secondary-btn-small"
                aria-label="Download sealed package ${pkg.name}"
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" class="w-3 h-3 icon-space"><path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" /></svg>
                Download
              </button>
            </div>
            <p class="text-xs text-gray-500 mt-2">
              Sealed: ${new Date(pkg.createdAt).toLocaleString()}
            </p>
            <p class="text-green-500 text-[10px] font-mono break-all mt-1">
              ${pkg.sha512}
            </p>
        `;
        sealedPackagesList.appendChild(pkgDiv);
    });

    // Add event listeners to newly created download buttons
    document.querySelectorAll('.download-package-btn').forEach(button => {
        button.onclick = async (event) => {
            const btn = event.currentTarget;
            const hash = btn.dataset.hash;
            const name = btn.dataset.name;
            const manifestBase64 = btn.dataset.manifest;

            if (manifestBase64) {
                try {
                    const manifestText = decodeURIComponent(atob(manifestBase64));
                    const { pdfBytes } = await window.voSealPdf({
                        title: `Verum Omnis V2 Sealed Evidence Bundle Manifest`,
                        body: manifestText,
                        sha512: hash,
                    });
                    window.voDownload(pdfBytes, name);
                } catch (error) {
                    console.error("Error re-sealing/downloading package:", error);
                    alert("Error downloading package. Check console for details.");
                }
            } else {
                alert("Manifest text not available for re-download. This package might be old or corrupted.");
            }
        };
    });
};

/**
 * Renders the governance ballots in the Nine-Brain panel.
 * @param {Array<Object>} ballots
 */
const renderNineBrainPanel = (ballots) => {
    if (!nineBrainPanel) return;
    governancePanel.classList.remove('hidden');
    nineBrainPanel.innerHTML = '';
    if (ballots.length === 0) {
        nineBrainPanel.innerHTML = `<p class="text-sm text-gray-500">No active governance rules triggered.</p>`;
        return;
    }
    ballots.forEach(ballot => {
        const ballotDiv = document.createElement('div');
        let statusColor = 'text-gray-400';
        if (ballot.score >= 0.8) statusColor = 'text-red-400';
        else if (ballot.score >= 0.5) statusColor = 'text-yellow-400';
        else if (ballot.score > 0) statusColor = 'text-blue-400';

        ballotDiv.className = `bg-gray-800 p-2 rounded-md border border-gray-700 ${statusColor}`;
        ballotDiv.innerHTML = `
            <p class="font-bold">${ballot.claim}</p>
            <p class="text-xs text-gray-500">Brain: ${ballot.id} (Score: ${ballot.score.toFixed(2)})</p>
            <p class="text-xs text-gray-500">Rule: ${ballot.rationale}</p>
        `;
        nineBrainPanel.appendChild(ballotDiv);
    });
};

/**
 * Renders the final governance decision.
 * @param {Object} finalDecision
 */
const renderFinalDecision = (finalDecision) => {
    if (!finalClaim || !finalConfidence) return;
    governancePanel.classList.remove('hidden');

    finalClaim.textContent = finalDecision.claim;
    finalConfidence.textContent = `Confidence: ${(finalDecision.confidence * 100).toFixed(1)}% (Quorum: ${finalDecision.quorum})`;

    let claimColor = 'text-gray-300';
    if (finalDecision.claim.includes('FLAG') || finalDecision.claim.includes('ESCALATE')) {
        claimColor = 'text-red-500';
    } else if (finalDecision.claim.includes('WARN')) {
        claimColor = 'text-yellow-500';
    } else if (finalDecision.claim.includes('NO_ACTION')) {
        claimColor = 'text-green-500';
    }
    finalClaim.className = `text-lg font-bold mt-1 ${claimColor}`;
};


// --- Core Logic Functions ---

/**
 * Fetches geolocation if supported and permission is granted.
 */
const getGeolocation = () => {
    return new Promise((resolve) => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    currentLocation = {
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude,
                    };
                    resolve(currentLocation);
                },
                (error) => {
                    console.warn("Geolocation access denied or error:", error.message);
                    const locationDeniedMessage = {
                        id: 'system-location-denied',
                        role: 'system',
                        text: "Location access was denied. For the most accurate jurisdiction-specific legal advice, please enable location services for this site in your browser settings."
                    };
                    // Only add if not already present
                    if (!messages.find(m => m.id === 'system-location-denied')) {
                        messages.push(locationDeniedMessage);
                        addMessageToDisplay(locationDeniedMessage);
                        storageService.saveItems(MESSAGES_STORE_NAME, messages);
                    }
                    resolve(null);
                }
            );
        } else {
            console.warn("Geolocation is not supported by this browser.");
            resolve(null);
        }
    });
};

/**
 * Sends a message to the AI and displays the response, including governance evaluation.
 * @param {string} input - User's text prompt.
 * @param {File | null} file - Attached file.
 */
const sendMessage = async (input, file = null) => {
    if ((!input.trim() && !file) || isLoading) return;
    if (!currentUser) { // Check if user is logged in
        alert("Please log in to use the chat functionality.");
        loginModal.classList.remove('hidden');
        return;
    }

    const userMessage = {
        id: Date.now().toString(),
        role: 'user',
        text: input,
        attachment: file ? { name: file.name, size: file.size, mimeType: file.type } : undefined,
    };
    messages.push(userMessage);
    addMessageToDisplay(userMessage);
    await storageService.saveItems(MESSAGES_STORE_NAME, messages);
    
    isLoading = true;
    askBtn.disabled = true;
    promptInput.disabled = true;
    attachFileBtn.disabled = true;
    if (voiceInputToggleBtn) voiceInputToggleBtn.disabled = true;
    showLoadingIndicator();
    if (fileProgressDiv) fileProgressDiv.classList.add('hidden'); // Hide file progress during AI call

    let lastUserStatement = '';
    let lastUserTimestamp = '';
    let lastUserActor = currentUser.uid; // Use current authenticated user's UID as actor

    const lastUserMessage = messages.slice().reverse().find(m => m.role === 'user');
    if (lastUserMessage) {
        lastUserStatement = lastUserMessage.text;
        lastUserTimestamp = new Date(parseInt(lastUserMessage.id, 10)).toISOString();
    }

    // --- Governance Context Building (example placeholders) ---
    // These values would ideally be derived from a richer client-side state
    // or through further client-side processing of attached files (e.g., OCR, metadata extraction).
    const currentAuthClaims = await getCurrentUserClaims();
    const institution_id = currentAuthClaims?.institution_id || null;
    const site_id = currentAuthClaims?.site_id || null;

    const latestAmount = Math.random() < 0.1 ? 1000000 : Math.floor(Math.random() * 1000); // Simulate some large amounts
    const latestCounterparty = Math.random() < 0.5 ? 'BankX' : 'ClientY';
    let latestDocHash = attachedFile ? await window.hashFileWithProgress(attachedFile) : null;
    const expectedChainHash = null; // In a real scenario, this would come from a blockchain anchor
    const latestVoiceToken = null; // Placeholder for actual voiceprint token
    const expectedVoiceToken = null; // Placeholder for expected voiceprint
    const latestSigToken = null; // Placeholder for signature token
    const expectedSigToken = null; // Placeholder for expected signature token
    const latestCitation = null; // Placeholder for legal citation
    const localPrecedentLookup = (citation) => citation ? "Found precedent for " + citation : null;
    const currentAnomalyScore = Math.random(); // Simulate R&D anomaly score
    const currentCategory = currentAnomalyScore > 0.8 ? 'unknown' : 'known'; // Simulate category

    // New fields for fraud-stop email context
    const detectedJurisdiction = currentLocation ? (currentLocation.latitude < 0 ? 'ZA' : 'US') : null; // Simple geo-based mock
    const transactionCategory = attachedFile ? (attachedFile.mimeType.includes('pdf') ? 'contract_review' : 'general_evidence') : (latestAmount > 50000 ? 'payment_fraud' : 'general_inquiry'); // Mock category

    // New fields for retail security brain (B10_Security_Retail)
    const mockLaneId = 'LANE' + Math.ceil(Math.random() * 3);
    const mockCashierIdHash = 'sha256:' + Math.random().toString(36).substring(2, 14);
    const mockEventType = ['BEEP', 'LINE_ADD', 'NO_SALE', 'DRAWER_OPEN'][Math.floor(Math.random() * 4)];
    const mockDrawerOpen = mockEventType === 'DRAWER_OPEN';
    const mockRepeats15m = Math.random() < 0.2 ? Math.ceil(Math.random() * 3) + 2 : 0; // Simulate repeats for fraud
    const mockPosTopClass = ['bottle', 'can', 'cig_pack', 'open_plu'][Math.floor(Math.random() * 4)];
    const mockVisionTopClass = ['bottle', 'can', 'energy_drink'][Math.floor(Math.random() * 3)];
    const mockSyncDeltaMs = Math.floor(Math.random() * 5000) - 2500; // -2.5s to +2.5s
    const mockVisionHasBarcodedClass = Math.random() < 0.8;
    const mockCabinetTakeDetected = Math.random() < 0.1;
    const mockPosMatchInWindow = Math.random() < 0.9;
    const mockFuelAuthorized = Math.random() < 0.05;
    const mockFuelSaleCaptured = mockFuelAuthorized ? Math.random() < 0.8 : false;
    const mockRepeats60m = Math.random() < 0.05 ? Math.ceil(Math.random() * 2) + 1 : 0;


    const ctx = {
        actor: currentUser.uid, // Use authenticated user's UID
        auth_uid: currentUser.uid, // Add auth_uid explicitly for logging/claims
        timestamp: new Date().toISOString(),
        statement: input,
        last_actor: lastUserActor,
        last_timestamp: lastUserTimestamp,
        last_statement: lastUserStatement,
        amount: latestAmount,
        counterparty: latestCounterparty,
        document_hash: latestDocHash,
        expected_hash: expectedChainHash,
        voiceprint: latestVoiceToken,
        expected_voiceprint: expectedVoiceToken,
        signature: latestSigToken,
        expected_signature: expectedSigToken,
        citation: latestCitation,
        legal_precedent: localPrecedentLookup(latestCitation),
        anomaly_score: currentAnomalyScore,
        category: currentCategory,
        threshold: 0.7,
        // Institution-specific context for email queue
        institution_name: 'Verum Omnis V2 Demo Inc.', // Placeholder for institution name
        institution_id: institution_id, // Pass institution_id from claims
        currency: 'USD', // Placeholder currency
        incident_id: `WEB-${Date.now().toString(36).toUpperCase()}`, // Generate incident ID
        jurisdiction: detectedJurisdiction, // New field
        category: transactionCategory, // New field
        // B10_Security_Retail context (mocked for web client)
        site_id: site_id, // Pass site_id from claims
        lane_id: mockLaneId,
        cashier_id_hash: mockCashierIdHash,
        event_type: mockEventType,
        drawer_open: mockDrawerOpen,
        repeats_15m: mockRepeats15m,
        pos_top_class: mockPosTopClass,
        vision_top_class: mockVisionTopClass,
        sync_delta_ms: mockSyncDeltaMs,
        vision_has_barcoded_class: mockVisionHasBarcodedClass,
        cabinet_take_detected: mockCabinetTakeDetected,
        pos_match_in_window: mockPosMatchInWindow,
        fuel_authorized: mockFuelAuthorized,
        fuel_sale_captured: mockFuelSaleCaptured,
        repeats_60m: mockRepeats60m,
    };

    try {
        // --- Run Governance Logic ---
        if (!giftRules) {
            console.warn("Governance rules not loaded. Attempting to load...");
            giftRules = await loadGiftRules();
        }
        // runGovernance now also calls enforceAction internally
        const gov = runGovernance(ctx, giftRules);
        renderNineBrainPanel(gov.ballots);
        renderFinalDecision(gov.final);
        await vaultAppend({ t:new Date().toISOString(), type:'governance', ctxDigest: ctx.statement?.slice(0,64), final: gov.final, ballots: gov.ballots.map(b=>({id:b.id,claim:b.claim,score:b.score})) });

        // --- Send to AI (proxied via Firebase Function) ---
        let fileData = null;
        if (file) {
            const base64Data = await window.fileToBase64(file);
            fileData = {
                name: file.name,
                mimeType: file.type,
                data: base64Data,
                size: file.size
            };
        }

        const idToken = await currentUser.getIdToken(); // Get ID token for authenticated requests
        const response = await fetch('/api/assistant', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${idToken}` // Include ID token
            },
            body: JSON.stringify({
                prompt: input,
                context: 'legal',
                mode: 'chat', // Current mode is always chat for this endpoint in functions
                location: currentLocation,
                file: fileData
            }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        const aiMessage = {
            id: (Date.now() + 1).toString(),
            role: 'model',
            text: data.text,
            rawResponses: data.rawParts,
        };
        messages.push(aiMessage);
        addMessageToDisplay(aiMessage);
        await storageService.saveItems(MESSAGES_STORE_NAME, messages);

    } catch (error) {
        console.error("Error in Triple-AI orchestration or Governance:", error);
        const errorMessage = {
            id: (Date.now() + 1).toString(),
            role: 'system',
            text: `Error: Could not get a response. Please check your connection or AI configuration. Governance failed: ${error.message}`
        };
        messages.push(errorMessage);
        addMessageToDisplay(errorMessage);
        await storageService.saveItems(MESSAGES_STORE_NAME, messages);
    } finally {
        isLoading = false;
        askBtn.disabled = false;
        promptInput.disabled = false;
        attachFileBtn.disabled = false;
        if (voiceInputToggleBtn) voiceInputToggleBtn.disabled = false;
        hideLoadingIndicator();
        // Reset file attachment after sending
        attachedFile = null;
        chatFileInput.value = '';
        attachedFileDisplay.classList.add('hidden');
        fileProcessingProgress = 0;
        if (fileProgressDiv) fileProgressDiv.classList.add('hidden');
    }
};

/**
 * Handles manual hash verification from the input field.
 * @param {string} [hashToVerify] - Optional hash to verify, if not provided, uses input field.
 */
const handleManualVerification = async (hashToVerify) => {
    const currentHash = (hashToVerify || sha512Input.value).toUpperCase();
    
    // Clear previous status
    verificationStatusDiv.classList.add('hidden');
    verificationStatusDiv.innerHTML = '';
    
    if (!currentHash || currentHash.length !== 128) {
        verificationStatusDiv.classList.remove('hidden');
        verificationStatusDiv.innerHTML = `<p class="text-sm text-red-500">Error: Invalid SHA-512 hash format.</p>`;
        return;
    }

    verificationStatusDiv.classList.remove('hidden');
    verificationStatusDiv.innerHTML = `<p class="text-sm text-yellow-400 animate-pulse">Verifying hash...</p>`;

    try {
        const idToken = currentUser ? await currentUser.getIdToken() : null; // Get ID token for authenticated requests
        const response = await fetch('/api/verify', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                ...(idToken && { 'Authorization': `Bearer ${idToken}` }) // Include ID token if available
            },
            body: JSON.stringify({ sha512_prefix: currentHash }),
        });
        const data = await response.json();

        if (!response.ok) { // Handle non-200 responses
            throw new Error(data.error || `Server responded with status: ${response.status}`);
        }

        if (data.ok) {
            const knownHashInfo = window.KNOWN_HASHES[currentHash];
            if (knownHashInfo) {
                verificationStatusDiv.innerHTML = `
                    <div class="flex items-start verification-status-success">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" class="w-5 h-5 icon-space flex-shrink-0 mt-0.5"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" /></svg>
                        <div>
                            <p class="font-bold">INTEGRITY CONFIRMED</p>
                            <p class="text-xs text-gray-300 mt-1">Type: ${knownHashInfo.type}</p>
                            <p class="text-xs text-gray-300">Document: ${knownHashInfo.name}</p>
                            <p class="text-xs text-gray-400 mt-2">This document is officially registered with Verum Omnis V2.</p>
                        </div>
                    </div>
                `;
            } else {
                 verificationStatusDiv.innerHTML = `
                    <div class="flex items-start verification-status-success">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" class="w-5 h-5 icon-space flex-shrink-0 mt-0.5"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" /></svg>
                        <div>
                            <p class="font-bold">INTEGRITY CONFIRMED (Unknown Document)</p>
                            <p class="text-xs text-gray-400 mt-1">The hash format is valid and acknowledged by the Verum Omnis V2 network, but this specific document is not in our official registry.</p>
                        </div>
                    </div>
                `;
            }
        } else {
            // This path should ideally be caught by !response.ok above, but as a safeguard:
            throw new Error(data.error || 'Verification failed on server.');
        }
    } catch (error) {
        console.error("Verification failed:", error);
        verificationStatusDiv.innerHTML = `
            <div class="flex items-start verification-status-fail">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" class="w-5 h-5 icon-space flex-shrink-0 mt-0.5"><path strokeLinecap="round" strokeLinejoin="round" d="m9.75 9.75 4.5 4.5m0-4.5-4.5 4.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" /></svg>
                <div>
                    <p class="font-bold">VERIFICATION FAILED</p>
                    <p class="text-xs text-gray-400 mt-1">${error.message}</p>
                </div>
            </div>
        `;
    }
};

/**
 * Handles a health check request.
 */
const handleHealthCheck = async () => {
    statusIndicator.className = 'w-3 h-3 bg-yellow-500 rounded-full animate-spin';
    statusText.textContent = 'Pinging services...';
    healthBtn.disabled = true;

    try {
        const idToken = currentUser ? await currentUser.getIdToken() : null; // Get ID token for authenticated requests
        const response = await fetch('/api/health', {
            headers: {
                ...(idToken && { 'Authorization': `Bearer ${idToken}` }) // Include ID token if available
            }
        });
        if (!response.ok) throw new Error('Health check failed');
        const data = await response.json();
        if (data.status === 'ok') {
            statusIndicator.className = 'w-3 h-3 bg-green-500 rounded-full animate-pulse';
            statusText.textContent = 'All Systems Operational';
            lastCheckP.textContent = `Last check: ${new Date(data.timestamp).toLocaleTimeString()}`;
        } else {
            throw new Error('Unexpected health status');
        }
    } catch (error) {
        console.error("Health check error:", error);
        statusIndicator.className = 'w-3 h-3 bg-red-500 rounded-full';
        statusText.textContent = 'Service Disruption';
        lastCheckP.textContent = `Last check: ${new Date().toLocaleTimeString()} (Error)`;
    } finally {
        healthBtn.disabled = false;
    }
};

/**
 * Handles running a forensic analysis on the chat transcript.
 */
const runForensicAnalysis = async () => {
    if (!currentUser) {
        alert("Please log in to run forensic analysis.");
        loginModal.classList.remove('hidden');
        return;
    }
    if (messages.length <= 1) { // Only the initial greeting, no actual conversation
        analysisContent.innerHTML = `<p class="prose prose-invert prose-sm max-w-none p-4 text-center">No sufficient conversation for analysis.</p>`;
        return;
    }

    const transcript = messages.map(msg => {
        let entry = `[${msg.role.toUpperCase()}] ${msg.text}`;
        if (msg.attachment) {
            entry += ` (Attachment: ${msg.attachment.name})`;
        }
        if (msg.rawResponses) {
            entry += `\n  --- Raw Responses ---\n`;
            msg.rawResponses.forEach(res => {
                entry += `  - ${res.provider}: ${res.text}\n`;
            });
            entry += `  ---------------------\n`;
        }
        return entry;
    }).join('\n');

    analysisContent.innerHTML = `
        <div class="flex flex-col items-center justify-center h-full text-center p-4">
            <div class="w-8 h-8 border-4 border-dashed rounded-full animate-spin border-blue-400"></div>
            <p class="mt-4 text-lg text-gray-300">Running Forensic Analysis...</p>
            <p class="text-sm text-gray-500">The Verum Omnis V2 Forensic Brain is examining the transcript...</p>
        </div>
    `;
    runAnalysisBtn.disabled = true;

    try {
        // This would ideally be a call to a dedicated Firebase Function endpoint
        // For now, it's a client-side mock based on the previous React App logic
        console.warn("Forensic analysis is currently a client-side mock. A Firebase Function proxy should be implemented for production.");

        const caseId = crypto.randomUUID();
        const timestamp = new Date().toISOString();
        const subject = "General Legal Inquiry"; // Placeholder
        const participants = messages.map(m => m.role).filter((value, index, self) => self.indexOf(value) === index).join(', ');
        
        const summary = messages.filter(m => m.role === 'user' && m.text).map(m => m.text.substring(0, Math.min(m.text.length, 50)) + (m.text.length > 50 ? "..." : "")).join("\n- ");

        let evidenceNotes = "No documentary evidence provided.";
        const attachments = messages.filter(m => m.attachment).map(m => m.attachment?.name);
        if (attachments.length > 0) {
            evidenceNotes = `Attached files: ${attachments.join(', ')}. Relevance to be determined.`;
        }

        const report = `## Verum Omnis V2 Forensic Report ##

**Case ID:** ${caseId}
**Analysis Timestamp:** ${timestamp}
**Subject Matter Classification:** ${subject}

### Key Entities & Chronology ###
- **Participants:** ${participants}
- **Timeline of Events:**
  - Initial user inquiry: ${summary.split('\n')[0] || 'N/A'}
  - Key discussion points:
    - ${summary || 'N/A'}

### Forensic Findings ###
1.  **Critical Legal Subjects:** The transcript primarily discusses general legal questions.
2.  **Potential Dishonesty/Inconsistency:** None detected.
3.  **Evidence Analysis:** ${evidenceNotes}

### Actionable Intelligence ###
- **Strategic Recommendations:**
  - Recommend further specific inquiry into relevant legal statutes.
  - Advise to consult with a human attorney for personalized advice.
  - 
- **Next Steps:**
  - Gather more specific details about the legal issue.
  - Research jurisdiction-specific laws.

--- END OF REPORT ---`;
        
        analysisContent.innerHTML = `
            <div class="prose prose-invert prose-sm max-w-none p-4 bg-gray-800 rounded-lg overflow-y-auto dark-scrollbar h-full">
                <pre class="whitespace-pre-wrap font-sans">${report}</pre>
                <button
                    id="rerun-analysis-btn"
                    class="btn primary-btn full-width-btn mt-4"
                    aria-label="Re-run forensic analysis"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" class="w-4 h-4 icon-space"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" /></svg>
                    Re-Run Analysis
                </button>
            </div>
        `;
        document.getElementById('rerun-analysis-btn').addEventListener('click', runForensicAnalysis);

    } catch (error) {
        console.error("Error generating forensic report:", error);
        analysisContent.innerHTML = `<p class="prose prose-invert prose-sm max-w-none p-4 text-red-500">Error: Could not generate the forensic report. The connection to the analysis engine failed.</p>`;
    } finally {
        runAnalysisBtn.disabled = false;
    }
};


// --- Event Handlers ---
chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (isListening && recognition) {
        recognition.stop(); // Stop listening if active
    }
    await sendMessage(promptInput.value, attachedFile);
});

// Handle Shift + Enter for new line in textarea
promptInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    chatForm.dispatchEvent(new Event('submit', { cancelable: true }));
  }
});

attachFileBtn.addEventListener('click', () => {
    chatFileInput.click();
});

chatFileInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (file) {
        attachedFile = file;
        attachedFileName.textContent = file.name;
        attachedFileDetails.textContent = `${window.formatBytes(file.size)} (${file.type})`;
        attachedFileDisplay.classList.remove('hidden');
        
        fileProcessingProgress = 1; // Start progress display
        if (fileProgressDiv) fileProgressDiv.classList.remove('hidden');
        if (fileProgressBar) fileProgressBar.style.width = `1%`;

        try {
            await window.fileToBase64(file, (progress) => {
                fileProcessingProgress = progress;
                if (fileProgressBar) fileProgressBar.style.width = `${progress}%`;
            });
            // Hashing is done on submission to the backend, not here.
            // This just prepares the file for sending.
            fileProcessingProgress = 100;
            if (fileProgressBar) fileProgressBar.style.width = `100%`;
        } catch (err) {
            console.error("File processing failed during preview:", err);
            attachedFile = null;
            chatFileInput.value = '';
            attachedFileDisplay.classList.add('hidden');
            alert("Error processing file. Please try a different file.");
        } finally {
            // Keep progress bar visible for a moment then hide
            setTimeout(() => {
                if (fileProgressDiv) fileProgressDiv.classList.add('hidden');
                fileProcessingProgress = 0;
            }, 500);
        }
    }
});

removeAttachedFileBtn.addEventListener('click', () => {
    attachedFile = null;
    chatFileInput.value = '';
    attachedFileDisplay.classList.add('hidden');
    fileProcessingProgress = 0;
    if (fileProgressDiv) fileProgressDiv.classList.add('hidden');
});

sha512Input.addEventListener('input', () => {
    // Reset verification status on input change
    verificationStatusDiv.classList.add('hidden');
    verificationStatusDiv.innerHTML = '';
});

verifyHashBtn.addEventListener('click', () => {
    handleManualVerification();
});

fileUploadInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    fileUploadText.textContent = `Hashing ${file.name}...`;
    verificationStatusDiv.classList.remove('hidden');
    verificationStatusDiv.innerHTML = `<p class="text-sm text-yellow-400 animate-pulse">Hashing file...</p>`;

    let currentFileProgress = 0;
    const updateFileUploadProgress = (progress) => {
        currentFileProgress = progress;
        fileUploadText.textContent = `Hashing ${file.name} (${Math.round(progress)}%)...`;
        // Implement a visual progress bar within the fileUploadText area if desired
    };

    try {
        const hashHex = await window.hashFileWithProgress(file, updateFileUploadProgress);
        sha512Input.value = hashHex; // Populate the main hash input
        fileUploadText.textContent = file.name; // Reset upload text
        
        // Add to evidence files, checking for duplicates
        if (!evidenceFiles.some(f => f.sha512 === hashHex)) {
            evidenceFiles.push({ name: file.name, sha512: hashHex, file: file, size: file.size, mimeType: file.type });
            await storageService.saveItems(EVIDENCE_STORE_NAME, evidenceFiles);
        }
        updateEvidenceLockerDisplay();
        handleManualVerification(hashHex); // Also verify the hash
    } catch (err) {
        console.error("File hashing failed:", err);
        verificationStatusDiv.innerHTML = `
            <div class="flex items-start verification-status-fail">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" class="w-5 h-5 icon-space flex-shrink-0 mt-0.5"><path strokeLinecap="round" strokeLinejoin="round" d="m9.75 9.75 4.5 4.5m0-4.5-4.5 4.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" /></svg>
                <div>
                    <p class="font-bold">HASHING FAILED</p>
                    <p class="text-xs text-gray-400 mt-1">Could not hash the file. Please try again.</p>
                </div>
            </div>
        `;
    } finally {
        fileUploadText.textContent = "Upload evidence to locker"; // Reset for next upload
    }
});

sealEvidenceBundleBtn.addEventListener('click', async () => {
    if (evidenceFiles.length === 0) return;
    sealEvidenceBundleBtn.disabled = true;
    sealEvidenceBundleBtn.textContent = 'Sealing...';

    let manifest = `Verum Omnis V2 Sealed Evidence Bundle\n`;
    manifest += `Created: ${new Date().toISOString()}\n\n`;
    manifest += `--- Included Evidence (${evidenceFiles.length} items) ---\n\n`;

    evidenceFiles.forEach(item => {
        manifest += `File: ${item.name}\n`;
        manifest += `Size: ${window.formatBytes(item.size)}\n`;
        manifest += `Type: ${item.mimeType}\n`;
        manifest += `SHA-512: ${item.sha512}\n\n`;
    });

    try {
        const manifestHash = await window.voHashText(manifest);
        const { pdfBytes } = await window.voSealPdf({
            title: "Verum Omnis V2 Sealed Evidence Bundle Manifest",
            body: manifest,
            sha512: manifestHash,
        });

        const now = new Date();
        const filename = `VERUM_OMNIS_V2_SEALED_EVIDENCE_BUNDLE_${now.toISOString().replace(/[:.]/g, '-')}.pdf`;
        window.voDownload(pdfBytes, filename);

        const newPackage = {
            name: filename,
            sha512: manifestHash,
            createdAt: now.toISOString(),
            manifestText: manifest, // Store manifest text to re-generate PDF on download click
        };
        sealedPackages.unshift(newPackage); // Add to beginning
        await storageService.saveItems(PACKAGES_STORE_NAME, sealedPackages);
        updateSealedPackagesDisplay();

        await vaultAppend({ t: new Date().toISOString(), type: 'evidence_sealed', filename: newPackage.name, hash: newPackage.sha512, auth_uid: currentUser ? currentUser.uid : 'anonymous' });

    } catch (error) {
        console.error("Failed to seal evidence bundle:", error);
        alert("Error sealing evidence bundle. Check console for details.");
    } finally {
        sealEvidenceBundleBtn.disabled = false;
        sealEvidenceBundleBtn.textContent = 'Seal Evidence Bundle';
    }
});


sealTranscriptBtn.addEventListener('click', async () => {
    if (messages.length === 0) return;
    sealTranscriptBtn.disabled = true;
    sealTranscriptBtn.textContent = 'Sealing...';

    let transcriptBody = `Verum Omnis V2 - Sealed Forensic Transcript\n`;
    transcriptBody += `Generated: ${new Date().toISOString()}\n\n---\n\n`;
    messages.forEach(msg => {
        transcriptBody += `[${msg.role.toUpperCase()}]\n${msg.text}\n\n`;
        if (msg.attachment) {
            transcriptBody += `  - [Attachment: ${msg.attachment.name} (${window.formatBytes(msg.attachment.size)}, ${msg.attachment.mimeType})]\n\n`;
        }
        if (msg.rawResponses) {
            transcriptBody += `  --- Triple-AI Raw Responses ---\n`;
            msg.rawResponses.forEach(res => {
                transcriptBody += `  - [${res.provider} Raw]: ${res.text}\n`;
            });
            transcriptBody += `  ------------------------------\n\n`;
        }
    });

    try {
        const transcriptHash = await window.voHashText(transcriptBody);
        const { pdfBytes } = await window.voSealPdf({
            title: "Verum Omnis V2 Sealed Forensic Transcript",
            body: transcriptBody,
            sha512: transcriptHash,
        });
        const now = new Date();
        const filename = `VERUM_OMNIS_V2_TRANSCRIPT_${now.toISOString().replace(/[:.]/g, '-')}.pdf`;
        window.voDownload(pdfBytes, filename);

        await vaultAppend({ t: new Date().toISOString(), type: 'transcript_sealed', filename: filename, hash: transcriptHash, auth_uid: currentUser ? currentUser.uid : 'anonymous' });

    } catch (error) {
        console.error("Failed to seal transcript:", error);
        alert("Error sealing transcript. Check console for details.");
    } finally {
        sealTranscriptBtn.disabled = false;
        sealTranscriptBtn.textContent = 'Seal Transcript to PDF';
    }
});

printTranscriptBtn.addEventListener('click', () => {
    window.print();
});

healthBtn.addEventListener('click', handleHealthCheck);

// --- Voice Input Logic ---
if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = false; // Listen for a single utterance
    recognition.interimResults = true; // Get results while speaking
    recognition.lang = 'en-US';

    voiceInputToggleBtn.classList.remove('hidden'); // Show button if supported

    recognition.onstart = () => {
        isListening = true;
        voiceInputToggleBtn.classList.add('listening');
        voiceInputToggleBtn.setAttribute('aria-label', 'Stop voice input');
        promptInput.placeholder = "Listening...";
        promptInput.classList.add('listening');
    };

    recognition.onresult = (event) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
                finalTranscript += transcript;
            } else {
                interimTranscript += transcript;
            }
        }
        // If final text is available, replace current input. Otherwise, append interim.
        if (finalTranscript) {
            promptInput.value = finalTranscript;
        } else {
            // This approach replaces the whole input to prevent fragments if user pauses
            // Consider more advanced logic for real-time appending if needed.
            promptInput.value = interimTranscript;
        }
    };

    recognition.onend = () => {
        isListening = false;
        voiceInputToggleBtn.classList.remove('listening');
        voiceInputToggleBtn.setAttribute('aria-label', 'Start voice input');
        promptInput.placeholder = "Describe your legal situation or attach a document...";
        promptInput.classList.remove('listening');
        // If final transcript was processed and input is still empty, clear it
        if (!promptInput.value.trim() && recognition.result) { // Check if recognition actually produced a result
            promptInput.value = '';
        }
    };

    recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        isListening = false;
        voiceInputToggleBtn.classList.remove('listening');
        voiceInputToggleBtn.setAttribute('aria-label', 'Start voice input');
        promptInput.placeholder = "Describe your legal situation or attach a document...";
        promptInput.classList.remove('listening');
        alert("Voice input error: " + event.error);
    };

    voiceInputToggleBtn.addEventListener('click', () => {
        if (isListening) {
            recognition.stop();
        } else {
            promptInput.value = ''; // Clear input before starting to listen
            recognition.start();
        }
    });
}

// Event listener for analysis panel button
if (runAnalysisBtn) {
    runAnalysisBtn.addEventListener('click', runForensicAnalysis);
}

// --- Auth State Listener ---
onAuthStateChanged(auth, async (user) => {
    currentUser = user;
    if (user) {
        userEmailDisplay.textContent = user.email;
        userEmailDisplay.classList.remove('hidden');
        authButton.textContent = 'Logout';
        authButton.onclick = signOutUser;
        // Re-enable chat elements if logged in
        promptInput.disabled = false;
        attachFileBtn.disabled = false;
        if (voiceInputToggleBtn) voiceInputToggleBtn.disabled = false;
        askBtn.disabled = false;

    } else {
        userEmailDisplay.textContent = '';
        userEmailDisplay.classList.add('hidden');
        authButton.textContent = 'Login';
        authButton.onclick = () => loginModal.classList.remove('hidden');
        // Disable chat elements if logged out
        promptInput.disabled = true;
        attachFileBtn.disabled = true;
        if (voiceInputToggleBtn) voiceInputToggleBtn.disabled = true;
        askBtn.disabled = true;
        // Clear chat messages on logout
        messages = [];
        await storageService.saveItems(MESSAGES_STORE_NAME, messages);
        chatMessages.innerHTML = '';
        // Display initial message on logout
        messages = [{
            id: 'initial',
            role: 'model',
            text: "Please log in to use Verum Omnis V2 Legal AI Chat."
        }];
        addMessageToDisplay(messages[0]);
    }
    // Update initial message after auth state change
    if (messages.length === 1 && messages[0].id === 'initial' && !user) {
         messages[0].text = "Please log in to use Verum Omnis V2 Legal AI Chat.";
         chatMessages.innerHTML = ''; // Clear existing initial message
         addMessageToDisplay(messages[0]);
    } else if (messages.length === 1 && messages[0].id === 'initial' && user) {
        messages[0].text = "Welcome to Verum Omnis V2. How can I assist you with your legal matter today?";
        chatMessages.innerHTML = '';
        addMessageToDisplay(messages[0]);
    }
});


// --- Initialization ---
document.addEventListener('DOMContentLoaded', async () => {
    // Login Modal Logic
    if (loginModal) {
        if (closeModalBtn) {
            closeModalBtn.addEventListener('click', () => {
                loginModal.classList.add('hidden');
                if (authErrorMessage) {
                    authErrorMessage.classList.add('hidden');
                    authErrorMessage.textContent = '';
                }
            });
        }

        if (emailLoginForm) {
            emailLoginForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                if (authErrorMessage) authErrorMessage.classList.add('hidden');
                const email = document.getElementById('email-input').value;
                const password = document.getElementById('password-input').value;
                try {
                    await signInWithEmail(email, password);
                    loginModal.classList.add('hidden');
                } catch (error) {
                    if (authErrorMessage) {
                        authErrorMessage.textContent = getAuthErrorMessage(error.code);
                        authErrorMessage.classList.remove('hidden');
                    }
                }
            });
        }

        if (googleLoginBtn) {
            googleLoginBtn.addEventListener('click', async () => {
                if (authErrorMessage) authErrorMessage.classList.add('hidden');
                try {
                    await signInWithGoogle();
                    loginModal.classList.add('hidden');
                } catch (error) {
                    if (authErrorMessage) {
                        authErrorMessage.textContent = getAuthErrorMessage(error.code);
                        authErrorMessage.classList.remove('hidden');
                    }
                }
            });
        }
    }


    // Load persisted data
    messages = await storageService.loadItems(MESSAGES_STORE_NAME);
    evidenceFiles = await storageService.loadItems(EVIDENCE_STORE_NAME);
    sealedPackages = await storageService.loadItems(PACKAGES_STORE_NAME);

    // Get current mode and hash from URL
    const urlParams = new URLSearchParams(window.location.search);
    const mode = urlParams.get('mode');
    const hashFragment = urlParams.get('hash') || window.location.hash.substring(1); // Get hash from fragment
    updateModeLabel(mode);

    // Show/hide analysis panel based on mode
    if (mode === 'tax') { // Using 'tax' as an example mode for institutional analysis
        if (analysisPanel) analysisPanel.classList.remove('hidden');
        if (analysisPromptText) analysisPromptText.textContent = messages.length <= 1 ? "A conversation is required to run analysis." : "";
        if (runAnalysisBtn) runAnalysisBtn.disabled = messages.length <= 1;
    }

    // If no history, add initial message (this will be updated by auth listener)
    if (messages.length === 0) {
        messages = [{
            id: 'initial',
            role: 'model',
            text: "Loading Verum Omnis V2..."
        }];
        await storageService.saveItems(MESSAGES_STORE_NAME, messages);
    }
    messages.forEach(addMessageToDisplay);


    // If mode is 'verify' and hash exists, pre-populate and verify
    if (mode === 'verify' && hashFragment) {
        if (sha512Input) {
          sha512Input.value = hashFragment;
          handleManualVerification(hashFragment);
        }
    }

    // Update UI components
    updateEvidenceLockerDisplay();
    updateSealedPackagesDisplay();
    handleHealthCheck(); // Initial health check

    // Get user geolocation
    await getGeolocation();

    // Load Governance Rules
    try {
        giftRules = await loadGiftRules();
        console.log("Governance rules loaded successfully.");
    } catch (error) {
        console.error("Failed to load governance rules:", error);
        alert(`CRITICAL: Governance rules could not be loaded or verified. Functionality may be limited. Error: ${error.message}`);
    }
});