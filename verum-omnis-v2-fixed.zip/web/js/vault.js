// web/js/vault.js
export async function vaultAppend(obj){
  // In WebView, forward to native plugin if available; otherwise localStorage fallback
  try{
    // Check if Capacitor is available and the plugin exists
    if (typeof Capacitor !== 'undefined' && Capacitor.Plugins && Capacitor.Plugins.Forensics) {
      await Capacitor.Plugins.Forensics.appendJsonl({relativePath:'vault/case_events.jsonl', line: JSON.stringify(obj)});
    } else {
      // Fallback to localStorage for browser environment
      const k='vo_vault';
      const arr=JSON.parse(localStorage.getItem(k)||'[]');
      arr.push(obj);
      localStorage.setItem(k,JSON.stringify(arr));
      console.log("Vaulted to localStorage:", obj);
    }
  }
  catch(e){
    console.warn("Vault append failed, falling back to localStorage if not already there:", e);
    const k='vo_vault';
    const arr=JSON.parse(localStorage.getItem(k)||'[]');
    arr.push(obj);
    localStorage.setItem(k,JSON.stringify(arr));
  }
}