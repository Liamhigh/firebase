// web/js/rules-loader.js
async function sha512Hex(ab){ const d=await crypto.subtle.digest('SHA-512',ab); return [...new Uint8Array(d)].map(b=>b.toString(16).padStart(2,'0')).join(''); }
function canonicalize(obj){ return JSON.stringify(obj, Object.keys(obj).sort()); }
async function importEd25519Pem(pem){
  const b64=pem.replace(/-----(BEGIN|END) PUBLIC KEY-----|\s/g,'');
  const der=Uint8Array.from(atob(b64),c=>c.charCodeAt(0));
  // Note: 'NODE-ED25519' is a specific identifier, it might need to be 'Ed25519' depending on the crypto backend
  // In a browser WebCrypto context, 'Ed25519' is the correct algorithm name.
  return crypto.subtle.importKey('spki',der,{name:'Ed25519',namedCurve:'Ed25519'},false,['verify']);
}
async function verifyEd25519(pubPem, payload, sigB64){
  const key=await importEd25519Pem(pubPem);
  const sig=Uint8Array.from(atob(sigB64),c=>c.charCodeAt(0));
  const data=new TextEncoder().encode(payload);
  try { return await crypto.subtle.verify({name:'Ed25519'}, key, sig, data); } catch { return false; }
}
export async function loadGiftRules(){
  try {
    const pub = await fetch('/assets/rules/public_key_ed25519.pem').then(r=>r.text());
    const m   = await fetch('/assets/rules/rulepack_manifest.json').then(r=>r.json());
    for (const f of m.files){
      const ab = await fetch(`/assets/rules/${f.path}`).then(r=>r.arrayBuffer());
      if ((await sha512Hex(ab))!==f.sha512) throw new Error(`Rule hash mismatch: ${f.path}`);
    }
    // Canonicalize manifest *without* signature for verification
    const manifestToVerify = { ...m };
    delete manifestToVerify.signature; // Remove signature field before canonicalizing for verification
    const ok = await verifyEd25519(pub, canonicalize(manifestToVerify), m.signature);
    if (!ok) throw new Error('Rulepack signature invalid');
    return await fetch('/assets/rules/gift_rules_v5.json').then(r=>r.json());
  } catch (error) {
    console.error("Failed to load or verify gift rules:", error);
    throw new Error(`Governance rules failed to load: ${error.message}`);
  }
}