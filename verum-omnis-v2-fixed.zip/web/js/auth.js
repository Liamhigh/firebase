// web/js/auth.js
// Centralized Firebase Authentication logic

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.4/firebase-app.js";
import { 
    getAuth, 
    createUserWithEmailAndPassword, 
    signInWithEmailAndPassword, 
    GoogleAuthProvider, 
    signInWithPopup, 
    signOut,
    onAuthStateChanged as firebaseOnAuthStateChanged // Alias to avoid conflict
} from "https://www.gstatic.com/firebasejs/10.12.4/firebase-auth.js";

// Firebase config should be set globally in index.html
if (!window.firebaseConfig) {
    console.error("Firebase config is not available globally (window.firebaseConfig). Please ensure it's defined in index.html.");
}

// Initialize Firebase App
const app = initializeApp(window.firebaseConfig);
export const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

/**
 * Handles user sign-up with email and password.
 * @param {string} email
 * @param {string} password
 * @returns {Promise<import("firebase/auth").UserCredential>}
 */
export async function signUpWithEmail(email, password) {
    return createUserWithEmailAndPassword(auth, email, password);
}

/**
 * Handles user sign-in with email and password.
 * @param {string} email
 * @param {string} password
 * @returns {Promise<import("firebase/auth").UserCredential>}
 */
export async function signInWithEmail(email, password) {
    return signInWithEmailAndPassword(auth, email, password);
}

/**
 * Handles user sign-in with Google popup.
 * @returns {Promise<import("firebase/auth").UserCredential>}
 */
export async function signInWithGoogle() {
    return signInWithPopup(auth, googleProvider);
}

/**
 * Handles user sign-out.
 * @returns {Promise<void>}
 */
export async function signOutUser() {
    return signOut(auth);
}

/**
 * Subscribes to authentication state changes.
 * @param {(user: import("firebase/auth").User | null) => void} callback
 * @returns {import("firebase/auth").Unsubscribe}
 */
export function onAuthStateChanged(callback) {
    return firebaseOnAuthStateChanged(auth, callback);
}

/**
 * Gets the current user's ID token and custom claims.
 * @returns {Promise<object | null>} Custom claims or null if no user.
 */
export async function getCurrentUserClaims() {
    if (auth.currentUser) {
        try {
            const idTokenResult = await auth.currentUser.getIdTokenResult();
            return idTokenResult.claims;
        } catch (error) {
            console.error("Error getting user claims:", error);
            return null;
        }
    }
    return null;
}

/**
 * Maps Firebase Auth error codes to user-friendly messages.
 * @param {string} errorCode - The Firebase Auth error code.
 * @returns {string} - A user-friendly error message.
 */
export function getAuthErrorMessage(errorCode) {
    switch (errorCode) {
        case 'auth/user-not-found':
        case 'auth/wrong-password':
            return 'Invalid email or password.';
        case 'auth/email-already-in-use':
            return 'Email already in use. Please login or use a different email.';
        case 'auth/weak-password':
            return 'Password is too weak (should be at least 6 characters).';
        case 'auth/invalid-email':
            return 'Invalid email address.';
        case 'auth/popup-closed-by-user':
            return 'Login popup closed. Please try again.';
        case 'auth/cancelled-popup-request':
            return 'Login popup already open or cancelled. Please try again.';
        case 'auth/network-request-failed':
            return 'Network error. Please check your internet connection.';
        default:
            console.error("Unhandled Firebase Auth error:", errorCode);
            return 'An unknown authentication error occurred. Please try again.';
    }
}
