// Constants for Verum Omnis V2
const VERUM_OMNIS_V2_GUARD_VERSION = 'v5.2.6';
const VERUM_OMNIS_V2_CONSTITUTION_HASH = 'F9812DF678DBD3B6BAD400FD518DD8F472AC0F9A070458C007993078C51BDF468B356FD8055703AE9107346133DB5174AD33D03A9A9914848824D78E439F5832';
const VERUM_OMNIS_V2_CHARTER_HASH = '11BBCC2F9CBC77D288ACD7BEC652EC57713A75204FF5A277DC048469382BA0A419B66CA1F97915B1548458CC8B22E11C0075809D1D18F411BF10C253815912C81'; // Adjusted to make unique

const KNOWN_HASHES = {
  [VERUM_OMNIS_V2_CONSTITUTION_HASH]: {
    name: "Verum Omnis V2 Constitution Master Sealed",
    type: "constitution",
  },
  [VERUM_OMNIS_V2_CHARTER_HASH]: {
    name: "Verum Omnis V2 Charter",
    type: "charter",
  },
};

// Utility functions for Hashing, PDF Sealing, and Downloads

/**
 * Converts an ArrayBuffer to a hexadecimal string.
 * @param {ArrayBuffer} buffer
 * @returns {string}
 */
const arrayBufferToHex = (buffer) => {
  return Array.from(new Uint8Array(buffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
};

/**
 * Hashes an ArrayBuffer using SHA-512 and returns a hexadecimal string.
 * @param {ArrayBuffer} arrayBuffer
 * @returns {Promise<string>} SHA-512 hash as a hex string.
 */
async function voHashBuffer(arrayBuffer) {
  const hashBuffer = await window.crypto.subtle.digest('SHA-512', arrayBuffer);
  return arrayBufferToHex(hashBuffer).toUpperCase();
}

/**
 * Hashes a text string using SHA-512 and returns a hexadecimal string.
 * @param {string} text
 * @returns {Promise<string>} SHA-512 hash as a hex string.
 */
async function voHashText(text) {
  const textEncoder = new TextEncoder();
  const data = textEncoder.encode(text);
  return voHashBuffer(data.buffer);
}

/**
 * Hashes a File object using SHA-512 and returns a hexadecimal string, with progress updates.
 * @param {File} file
 * @param {(progress: number) => void} [onProgress] - Callback for progress updates (0-100).
 * @returns {Promise<string>} SHA-512 hash as a hex string.
 */
async function hashFileWithProgress(file, onProgress) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const buffer = event.target?.result;
        if (!buffer) return reject(new Error("Failed to read file buffer."));
        const hashBuffer = await window.crypto.subtle.digest('SHA-512', buffer);
        resolve(arrayBufferToHex(hashBuffer).toUpperCase());
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = (error) => reject(error);
    if (onProgress) {
      reader.onprogress = (event) => {
        if (event.lengthComputable) {
          const percent = (event.loaded / event.total) * 100;
          onProgress(percent);
        }
      };
    }
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Converts a File object to a Base64 string, with progress updates.
 * @param {File} file
 * @param {(progress: number) => void} [onProgress] - Callback for progress updates (0-100).
 * @returns {Promise<string>} Base64 string of the file content.
 */
function fileToBase64(file, onProgress) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      if (typeof reader.result !== 'string') {
        return reject(new Error('FileReader result is not a string'));
      }
      const base64String = reader.result.split(',')[1];
      resolve(base64String);
    };
    reader.onerror = error => reject(error);
    if (onProgress) {
      reader.onprogress = (event) => {
        if (event.lengthComputable) {
          const percent = (event.loaded / event.total) * 100;
          onProgress(percent);
        }
      };
    }
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Formats a byte count into a human-readable string (e.g., "1.2 MB").
 * @param {number} bytes - The number of bytes.
 * @param {number} [decimals=2] - The number of decimal places.
 * @returns {string} The formatted string.
 */
const formatBytes = (bytes, decimals = 2) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};


/**
 * Generates a QR code data URL for a given text.
 * @param {string} text
 * @returns {string} Data URL of the QR code image.
 */
const generateQrCode = (text) => {
  const qr = qrcode(0, 'L'); // 'L' for error correction level (Low)
  qr.addData(text);
  qr.make();
  return qr.createDataURL(4); // Scale factor 4
};

/**
 * Seals a transcript or evidence bundle into a PDF.
 * @param {object} options
 * @param {string} options.title - The title of the document.
 * @param {string} options.body - The main text content of the document.
 * @param {string} options.sha512 - The SHA-512 hash of the document content.
 * @param {string} [options.watermarkText='VERUM OMNIS V2 - CONFIDENTIAL'] - The watermark text.
 * @returns {Promise<{pdfBytes: Uint8Array, sha512: string}>} PDF bytes and the SHA-512 of the body.
 */
async function voSealPdf({ title, body, sha512, watermarkText = 'VERUM OMNIS V2 - CONFIDENTIAL' }) {
  const { PDFDocument, rgb, StandardFonts } = PDFLib;

  const pdfDoc = await PDFDocument.create();
  let page = pdfDoc.addPage();
  const { width, height } = page.getSize();
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontMono = await pdfDoc.embedFont(StandardFonts.Courier);

  const margin = 50;
  const lineHeight = 12;
  let y = height - margin;

  // Add a placeholder logo image (or could fetch from a fixed URL)
  const logoDataUrl = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGZpbGw9Im5vbmUiIHZpZXdCb3g9IjAgMCAyNCAyNCIgc3Ryb2tlV2lkdGg9IjEuNSIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiPjxwYXRoIHN0cm9rTGluZWNhcD0icm91bmQiIHN0cm9rZUxpbWVsN2UgbC0uOTY2LTIuNzQtLjU3LTIuODIyLTMuMDEgNC4yNC0uOTA5LTIuMzktLjg3Mi0yLjM2OS0zLjQ0NyAyLjMxNi0xLjY0OS0yLjM2NS0wLjE5NS0xLjAzLTEuMjk2LTIuMTM2LTIuNTAxLTEuNDY3LTAuOTk0LTAuNDcyLTAuNDgzLTAuNjEtMS40MTEtMC44MjktMS41Mi0wLjQ5OC0wLjc1LTAuMTU1LTAuNjAyLTAuMDY5LTAuMzktMC4yMjUtMC4yODQtMC4zODQtMC40NzYtMC40MzUtMC40OS0wLjQ3LTAuMzY4LTAuNDg2LTAuMjYtMC41ODQtMC4xNC0wLjU4Ny0wLjAxMy0wLjUwNS0wLjAzMy0wLjQwNi0wLjU4Mi0yLjI0Mi0wLjU4Mi0yLjI0Mi0wLjk4LTAuMjk0LTAuNjc3LTAuMTkzLTAuNDk1LTAuMTQ0LTAuNDE4LTAuMTU2LTAuMjQtMC4xMzQtMC4xNDktMC4yMjctMC4wNTctMC4yNjktMC4xMTItMC4xNzQtMC4xNjktMC4xOTQtMC4yMDEtMC4yMzUtMC4wMTItMC4wNzQtMC4xMjItMC4wMjYtMC4xMDktMC4wMjEtMC4wOTQtMC4wNzUtMC4wOTktMC4wNjUtMC4xMjktMC4wMjYtMC4wNzQtMC4wMDgtMC4wOTktMC4wMi0wLjA5My0wLjAyLTAuMTI5LTAuMDQtMC4wOTMtMC4wMi0wLjEwMi0wLjA4LTAuMDc4LTAuMDE3LTAuMDcyLTAuMDItMC4wNy0wLjAzLTAuMDI2LTAuMDItMC4wMi0wLjA1LTAuMDE3LTAuMDI3LTAuMDE3LTAuMDItMC4wMjctMC4wMS0wLjAyLTAuMDEtMC4wMi0wLjAxLTAuMDEtMC4wMS0wLjAxMi0wLjAxLTAuMDEyLTAuMDEtMC4wMTQtMC4wMS0wLjAxOC0wLjAxLTAuMDE2LTAuMDEtMC4wMTctMC4wMS0wLjAxLTAuMDEtMC4wMS0wLjAxMi0wLjAxMS02LjUzNC0yLjI0Mi0wLjU4Mi01LjQyOS0xLjMyNi03LjQyNy0zLjg1NS0xMC45N0wxMCAzLjc1WiIgLz48L3N2Zz4K'; // Example SVG for "Verum Omnis V2 Logo"
  const logoImage = await pdfDoc.embedPng(logoDataUrl); // Or embedJpg
  const logoDims = logoImage.scale(0.1); // Adjust scale as needed
  page.drawImage(logoImage, {
    x: (width / 2) - (logoDims.width / 2),
    y: y - logoDims.height - 10,
    width: logoDims.width,
    height: logoDims.height,
  });
  y -= logoDims.height + 20; // Move Y down past logo

  // Title
  page.drawText(title, { x: margin, y, font: fontBold, size: 18, color: rgb(0,0,0) });
  y -= 30;

  // Body Text
  const textLines = page.drawText(body, {
    x: margin,
    y: y,
    font: font,
    size: 9,
    lineHeight: lineHeight,
    color: rgb(0,0,0),
    maxWidth: width - margin * 2,
    wordBreaks: [' '], // Split by spaces for wrapping
  });

  // Calculate actual height used by text and adjust y
  const textHeightUsed = textLines.reduce((acc, line) => acc + lineHeight, 0);
  y -= textHeightUsed;


  // Handle pagination for remaining text
  let remainingText = body.substring(textLines.reduce((acc, line) => acc + line.length, 0));
  while (remainingText.length > 0) {
      page = pdfDoc.addPage();
      y = height - margin;

      // Re-add logo on new page
      page.drawImage(logoImage, {
          x: (width / 2) - (logoDims.width / 2),
          y: y - logoDims.height - 10,
          width: logoDims.width,
          height: logoDims.height,
      });
      y -= logoDims.height + 20;

      const newTextLines = page.drawText(remainingText, {
          x: margin,
          y: y,
          font: font,
          size: 9,
          lineHeight: lineHeight,
          color: rgb(0,0,0),
          maxWidth: width - margin * 2,
          wordBreaks: [' '],
      });
      const newTextHeightUsed = newTextLines.reduce((acc, line) => acc + lineHeight, 0);
      y -= newTextHeightUsed;
      remainingText = remainingText.substring(newTextLines.reduce((acc, line) => acc + line.length, 0));
  }
  
  // Watermark on all pages
  const pages = pdfDoc.getPages();
  for (const p of pages) {
      p.drawText(watermarkText, {
        x: p.getWidth() / 2 - 150,
        y: p.getHeight() / 2,
        font: fontBold,
        size: 50,
        color: rgb(0.85, 0.85, 0.85),
        rotate: PDFLib.degrees(45),
        opacity: 0.5,
      });
  }

  // Footer block on the last page
  const lastPage = pages[pages.length - 1];
  const qrCodeData = `${window.location.origin}/chat.html?mode=verify&hash=${sha512}`;
  const qrDataUrl = generateQrCode(qrCodeData);
  const qrImage = await pdfDoc.embedPng(qrDataUrl);
  const qrSize = 60;
  
  lastPage.drawRectangle({
    x: margin,
    y: margin - 10,
    width: width - margin * 2,
    height: qrSize + 20,
    color: rgb(0.95, 0.95, 0.95),
    opacity: 0.8,
  });
  
  lastPage.drawImage(qrImage, {
      x: width - margin - qrSize,
      y: margin,
      width: qrSize,
      height: qrSize
  });

  lastPage.drawText('✔ Patent Pending Verum Omnis V2', { x: margin + 10, y: margin + qrSize - 15, font: fontBold, size: 10, color: rgb(0,0,0) });
  lastPage.drawText(`Created: ${new Date().toLocaleString()}`, { x: margin + 10, y: margin + qrSize - 30, font, size: 8, color: rgb(0,0,0) });
  lastPage.drawText('SHA-512:', { x: margin + 10, y: margin + 15, font: fontMono, size: 6, color: rgb(0,0,0) });
  lastPage.drawText(sha512, { x: margin + 10, y: margin + 5, font: fontMono, size: 6, maxWidth: width - margin*2 - qrSize - 20, color: rgb(0,0,0) });

  const pdfBytes = await pdfDoc.save();
  return { pdfBytes, sha512: sha512 };
}

/**
 * Downloads a byte array as a file.
 * @param {Uint8Array} bytes
 * @param {string} filename
 * @param {string} mimeType
 */
function voDownload(bytes, filename, mimeType = 'application/pdf') {
  try {
    const blob = new Blob([bytes], { type: mimeType });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
  } catch (error) {
    console.error("Failed to download file:", error);
    alert("Error downloading file. Please try again.");
  }
}

// Expose these utilities globally for chat.js
window.voHashBuffer = voHashBuffer;
window.voHashText = voHashText;
window.hashFileWithProgress = hashFileWithProgress; // Export with progress
window.fileToBase64 = fileToBase64; // Export with progress
window.formatBytes = formatBytes; // Export new utility
window.voSealPdf = voSealPdf;
window.voDownload = voDownload;
window.KNOWN_HASHES = KNOWN_HASHES;
window.VERUM_OMNIS_V2_CONSTITUTION_HASH = VERUM_OMNIS_V2_CONSTITUTION_HASH;
window.VERUM_OMNIS_V2_CHARTER_HASH = VERUM_OMNIS_V2_CHARTER_HASH;
window.VERUM_OMNIS_V2_GUARD_VERSION = VERUM_OMNIS_V2_GUARD_VERSION; // Add guard version globally