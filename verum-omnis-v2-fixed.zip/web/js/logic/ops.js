// web/js/logic/ops.js
export const eq=(a,b)=>a===b;
export const neq=(a,b)=>a!==b;
export const missing=a=>a===undefined||a===null||a==='';
export const gt=(a,b)=>typeof a==='number'&&typeof b==='number'&&a>b; // Greater than
export const lt=(a,b)=>typeof a==='number'&&typeof b==='number'&&a<b; // Less than
// naive antonyms (extend as needed)
const ant={paid:'not_paid',delivered:'not_delivered',authorised:'unauthorised',true:'false',yes:'no',confirm:'deny',present:'absent',consistent:'inconsistent'};
const norm=s=>String(s||'').trim().toLowerCase();
export const contradicts=(a,b)=>!!a&&!!b&&(ant[norm(a)]===norm(b)||ant[norm(b)]===norm(a));
export const overlaps=(a,b)=>{try{const A=+new Date(a),B=+new Date(b);return Math.abs(A-B)<=5*60*1000;}catch{return false}};
export const outlier=(v,mean)=>typeof v==='number'&&typeof mean==='number'&&Math.abs(v-mean)>Math.max(3,0.25*mean);
export const anomalous=(cp,tr)=>Array.isArray(tr)?!tr.includes(cp):true;