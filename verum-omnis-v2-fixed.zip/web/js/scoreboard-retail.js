import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.4/firebase-app.js";
import { getFirestore, doc, onSnapshot, collection, query, orderBy, limit } from "https://www.gstatic.com/firebasejs/10.12.4/firebase-firestore.js";

// Ensure FB_CONFIG and SITE_ID are available in the window scope
if (!window.FB_CONFIG || !window.SITE_ID) {
    console.error("Firebase config (FB_CONFIG) or Site ID (SITE_ID) is missing in window object.");
    alert("CRITICAL: Scoreboard configuration missing. Please ensure SITE_ID and FB_CONFIG are set.");
}

// Initialize Firebase (only if not already initialized)
let app;
if (!initializeApp.length || !initializeApp()._apps.length) {
    app = initializeApp(window.FB_CONFIG);
} else {
    app = initializeApp()[0];
}
const db  = getFirestore(app);

const siteId = window.SITE_ID; // From global variable
const siteNameDisplay = document.getElementById('siteNameDisplay');

// Fetch site name once for display
const siteDocRef = doc(db, `sites/${siteId}`);
onSnapshot(siteDocRef, (snap) => {
  if (snap.exists()) {
    const data = snap.data();
    if (data && data.name) {
      siteNameDisplay.textContent = `Site: ${data.name}`;
    } else {
      siteNameDisplay.textContent = `Site: ${siteId}`; // Fallback to ID
    }
  } else {
    siteNameDisplay.textContent = `Site: Not Found (${siteId})`;
    console.warn(`Site document 'sites/${siteId}' not found.`);
  }
});


const statsRef = doc(db, `sites/${siteId}/live/retail`);
onSnapshot(statsRef, snap=>{
  const s = snap.data()||{};
  document.getElementById('incAll').textContent = (s.incidents_all||0).toLocaleString();
  document.getElementById('amtDay').textContent = (s.amount_today||0).toLocaleString(undefined,{minimumFractionDigits:2, maximumFractionDigits:2});
  document.getElementById('critDay').textContent= (s.crit_today||0).toLocaleString();
});

const recentRetailList = document.getElementById('recentRetail');
let recentIncidents = []; // To store the full incident data

const recentQ = query(collection(db, `sites/${siteId}/retailIncidents`), orderBy("received_at","desc"), limit(20));
onSnapshot(recentQ, snap=>{
  const items = [];
  snap.forEach(d=>items.push(d.data()));
  recentIncidents = items; // Store the full data for the details modal
  
  // Only re-render if there's a new item or order change
  const currentItemIds = Array.from(recentRetailList.children).map(li => (li).dataset.incidentId);
  const newItemIds = items.map(i => i.incident_id);

  if (newItemIds.length === 0 || !currentItemIds.every((id, idx) => id === newItemIds[idx])) {
    recentRetailList.innerHTML = items.map(i=>`
      <li data-incident-id="${i.incident_id}" class="tick">
        <strong>${i.severity}</strong> ${i.rule_id} — ${i.currency||''} ${i.amount_estimated.toLocaleString(undefined,{maximumFractionDigits:2})} <em>${new Date(i.ts).toLocaleTimeString()}</em>
      </li>`).join('');
    animateTicks(recentRetailList);
  }
  
  drawSpark(items);
});

function animateTicks(listElement){
  listElement.querySelectorAll('.tick').forEach((el, idx)=> {
    el.style.animationDelay = `${idx*0.03}s`;
  });
}

function drawSpark(items){
  const c = document.getElementById('sparkRetail');
  if (!c) return;
  const g=c.getContext('2d');
  if (!g) return;

  const w=c.width=c.clientWidth,h=c.height=c.clientHeight; g.clearRect(0,0,w,h);
  
  const now=Date.now();
  const intervalMs = 5 * 60 * 1000; // 5 minutes
  const numIntervals = 24; // 24 * 5 min = 2 hours
  const earliestTime = now - (numIntervals * intervalMs);

  const series = new Array(numIntervals).fill(0);
  
  // Aggregate incidents into time bins
  for(const i of items){
    const t=new Date(i.ts).getTime();
    if (t >= earliestTime && t <= now) {
      const index = Math.floor((t - earliestTime) / intervalMs);
      if (index >= 0 && index < numIntervals) {
        series[index]++;
      }
    }
  }

  const m=Math.max(1,...series); // Max incidents in any bin
  g.strokeStyle='#376bff'; // Brand color for the line
  g.lineWidth=1.5;
  g.beginPath();
  series.forEach((v,ix)=>{
    const x=(ix/(numIntervals-1))*w;
    const y=h-(v/m)*h;
    if (ix===0) g.moveTo(x,y); else g.lineTo(x,y);
  });
  g.stroke();
}


// --- NEW: Incident Detail Modal Logic ---
const incidentDetailModal = document.getElementById('incident-detail-modal');
if (incidentDetailModal) {
    const closeBtn = incidentDetailModal.querySelector('.modal-close-btn');
    if(closeBtn) {
        closeBtn.addEventListener('click', () => {
            incidentDetailModal.classList.add('hidden');
        });
    }

    if (recentRetailList) {
        recentRetailList.addEventListener('click', (event) => {
            const li = event.target.closest('li[data-incident-id]');
            if (!li) return;
            
            const incidentId = li.dataset.incidentId;
            const incident = recentIncidents.find(i => i.incident_id === incidentId);

            if (incident) {
                const contentDiv = document.getElementById('incident-details-content');
                if (!contentDiv) return;

                const details = {
                    "Incident ID": incident.incident_id,
                    "Timestamp": new Date(incident.ts).toLocaleString(),
                    "Severity": incident.severity,
                    "Rule ID": incident.rule_id,
                    "Action": incident.action,
                    "Category": incident.category || 'N/A',
                    "Lane ID": incident.lane_id || 'N/A',
                    "Est. Amount": `${incident.currency || ''}${incident.amount_estimated.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})}`,
                    "Cashier ID Hash": incident.cashier_id_hash ? `...${incident.cashier_id_hash.slice(-12)}` : 'N/A',
                    "Hash Prefix": incident.hash_prefix || 'N/A'
                };

                contentDiv.innerHTML = Object.entries(details).map(([key, value]) => `
                    <div class="detail-row">
                        <span class="detail-key">${key}:</span>
                        <span class="detail-value">${value}</span>
                    </div>
                `).join('');
                
                incidentDetailModal.classList.remove('hidden');
            }
        });
    }
}
