# Verum Omnis V2 - The World's First Legal AI

Verum Omnis V2 is a groundbreaking legal AI platform designed with client-side forensics, court-ready outputs, and Triple-AI consensus analysis. It prioritizes user privacy and data security, ensuring a stateless experience for private individuals.

## Non-negotiable Principles

*   **Two pages only**: `index.html` (Landing) and `chat.html` (Chat interface).
*   **Dark, forensic theme**: Mobile-first, accessible (ARIA, keyboard, proper contrast).
*   **Stateless for private users**: No analytics, no external trackers, no file uploads to server. Hashes computed locally in the browser.
*   **Court-ready PDF sealing** (client-side): Watermark, top-center logo, bottom-right certification block “✔ Patent Pending Verum Omnis V2”, visible SHA-512, ISO timestamp, QR that encodes a local verify fragment.
*   **Deployable now** on Firebase Hosting (+ minimal Functions proxy stub for `/api/assistant`).
*   **Zero secrets in the browser**.
*   **Triple-AI doctrine**: Chat prompts are sent to three separate LLM endpoints in parallel, and a consensus answer is synthesized. API keys are strictly server-side (Firebase Functions).

## Repository Layout

```
verum-omnis/
  web/                      # Static HTML, CSS, JS for Hosting
    assets/
      img/
        mainlogo.png
        logo2.png
        logo3.png
      video/
        176106381459.mp4        # optional hero video if used (placeholder)
        bank_promo.mp4           # placeholder
        bank_promo_long_1.mp4    # placeholder
    css/
      style.css               # Shared CSS
    js/
      script.js                 # Hashing + PDF seal + QR helpers
      chat.js                   # Chat UI logic, auto-scroll, IndexedDB, print, etc.
    index.html                # Landing page
    chat.html                 # Chat interface
  functions/                # Firebase Functions (Node 20 + Express)
    src/index.ts            # /api router, security headers, rate limits
    src/routes/assistant.ts # POST /assistant — triple LLM proxy
    package.json
    tsconfig.json
  .firebaserc
  firebase.json
  .github/workflows/deploy.yml
  README.md
  DEPLOYMENT.md
  SECURITY.md
```

## Quick Start (Local Development)

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-repo/verum-omnis.git
    cd verum-omnis
    ```
2.  **Firebase Setup:**
    *   If you don't have it, install the Firebase CLI: `npm install -g firebase-tools`
    *   Login to Firebase: `firebase login`
    *   Initialize Firebase project (if new): `firebase init`
        *   Choose "Hosting" and "Functions".
        *   For Hosting public directory, use `web` (this is where the static HTML/JS app is).
        *   Configure as a single-page app: `No` (since we have two distinct HTML pages, let Firebase handle them explicitly).
        *   For Functions, choose TypeScript and install dependencies.
    *   Update `.firebaserc` with your Firebase project ID if not set by `firebase init`.
    *   Set your Google Gemini API Key as an environment variable for Firebase Functions:
        ```bash
        firebase functions:config:set genai.api_key="YOUR_GEMINI_API_KEY"
        # The functions/src/routes/assistant.ts will read this as process.env.API_KEY
        ```
3.  **Install Functions Dependencies:**
    ```bash
    cd functions
    npm install
    npm run build
    cd ..
    ```
4.  **Place Assets:**
    Ensure placeholder images (`web/assets/img/mainlogo.png`, `logo2.png`, `logo3.png`) and videos (`web/assets/video/176106381459.mp4`, etc.) are in their respective `web/assets` directories. You might need to create dummy files or download actual placeholders if desired.
5.  **Run Locally:**
    ```bash
    firebase emulators:start --only hosting,functions
    ```
    This will start local servers. The web app will typically be available at `http://localhost:5000` (or similar).

## API Key Configuration

The Google Gemini API Key **must** be configured as an environment variable in your Firebase project for the `functions` service. It is **never** exposed in client-side code.

To set the API key:
```bash
firebase functions:config:set genai.api_key="YOUR_GEMINI_API_KEY"
# This will be accessible in your functions as process.env.API_KEY
```
**Important:** Ensure your `functions/src/routes/assistant.ts` correctly reads `process.env.API_KEY`.

## Example API Calls (using `curl`)

### 1. `POST /api/assistant` (Triple-AI Legal Query)

```bash
curl -X POST -H "Content-Type: application/json" \
     -d '{
           "prompt": "What are the legal implications of a smart contract defaulting?",
           "context": "legal",
           "mode": "chat",
           "location": {"latitude": 34.0522, "longitude": -118.2437}
         }' \
     http://localhost:5000/api/assistant
```

Expected (truncated) response:
```json
{
  "text": "DeepSeek Analysis Stub: The query concerns established legal precedents. Recommend reviewing similar case files for comparative analysis. The user should focus on the chain of custody for digital evidence.",
  "rawParts": [
    { "provider": "Gemini", "text": "..." },
    { "provider": "DeepSeek", "text": "..." },
    { "provider": "Claude", "text": "..." }
  ]
}
```

### 2. `POST /api/verify` (Stateless Hash Verification)

```bash
curl -X POST -H "Content-Type: application/json" \
     -d '{
           "sha512_prefix": "F9812DF678DBD3B6BAD400FD518DD8F472AC0F9A070458C007993078C51BDF468B356FD8055703AE9107346133DB5174AD33D03A9A9914848824D78E439F5832"
         }' \
     http://localhost:5000/api/verify
```

Expected response:
```json
{
  "ok": true,
  "sha512_prefix": "F9812DF678DBD3B6BAD400FD518DD8F472AC0F9A070458C007993078C51BDF468B356FD8055703AE9107346133DB5174AD33D03A9A9914848824D78E439F5832"
}
```
### 3. `GET /api/health` (Health Check)
```bash
curl http://localhost:5000/api/health
```
Expected response:
```json
{
  "status": "ok",
  "timestamp": "2024-07-30T12:34:56.789Z"
}
```

---
**Next Steps:** See `DEPLOYMENT.md` and `SECURITY.md` for more details.